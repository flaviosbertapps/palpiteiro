# -*- coding: utf-8 -*-
"""
e4_baixar_todos_precos.py - VERSAO CORRIGIDA
==============================================
Baixa precos historicos SEM ajuste automatico.

CORRECOES CRITICAS:
1. auto_adjust=False - Usa Close (nominal) para DY
2. Usa Adj Close APENAS para retornos
3. Calculo eficiente com rolling window

USO:
    python e4_baixar_todos_precos.py
    python e4_baixar_todos_precos.py --periodo 10
    python e4_baixar_todos_precos.py --continuar
"""

import sys
import os

# SOLUCAO ROBUSTA PARA WINDOWS
if sys.platform == 'win32':
    try:
        import io
        if sys.stdout.encoding != 'cp1252':
            sys.stdout = io.TextIOWrapper(
                sys.stdout.buffer, 
                encoding='cp1252', 
                errors='replace',
                line_buffering=True
            )
        if sys.stderr.encoding != 'cp1252':
            sys.stderr = io.TextIOWrapper(
                sys.stderr.buffer, 
                encoding='cp1252', 
                errors='replace',
                line_buffering=True
            )
    except (AttributeError, ValueError):
        pass

import yfinance as yf
import pandas as pd
import numpy as np
import time
from datetime import datetime, timedelta
import json
import argparse

import e4_database as db

# Carrega config
with open("e4_config.json", encoding='utf-8') as f:
    CFG = json.load(f)


def verificar_tem_dados(ticker: str, database) -> bool:
    """Verifica se ja tem dados deste ticker"""
    try:
        count = database.contar_registros_precos(ticker)
        return count > 0
    except:
        return False


def baixar_precos_ticker(ticker: str, anos: int = 10):
    """
    Baixa precos e dividendos de um ticker.
    
    CORRECOES CRITICAS:
    1. auto_adjust=False - Mantem precos nominais
    2. Close = preco nominal para DY
    3. Adj Close = preco ajustado para retornos
    4. Calculo eficiente com resample + rolling
    
    Args:
        ticker: Ticker com .SA
        anos: Quantos anos de historico
    
    Returns:
        tuple: (sucesso, dias_com_dy) ou DataFrame em caso de erro
    """
    try:
        # Define periodo
        data_fim = datetime.now()
        data_inicio = data_fim - timedelta(days=anos * 365)
        
        # CRITICO: auto_adjust=False para manter precos nominais
        hist = yf.download(
            ticker,
            start=data_inicio,
            end=data_fim,
            auto_adjust=False,  # <- CORRECAO CRITICA!
            progress=False
        )
        
        if hist.empty:
            return False, 0
        
        # Se yfinance retornar MultiIndex columns, flatten
        if isinstance(hist.columns, pd.MultiIndex):
            hist.columns = hist.columns.get_level_values(0)
        
        # Remove timezone se existir
        if hist.index.tz is not None:
            hist.index = hist.index.tz_localize(None)
        
        # Busca dividendos
        ticker_obj = yf.Ticker(ticker)
        dividendos = ticker_obj.dividends
        
        if dividendos.empty:
            # Sem dividendos, DY = 0
            df_final = hist.copy()
            df_final['dy_12m'] = 0.0
            dias_com_dy = 0
        else:
            # Remove timezone dos dividendos
            if dividendos.index.tz is not None:
                dividendos.index = dividendos.index.tz_localize(None)
            
            # METODO EFICIENTE: Resample + Rolling
            # 1. Converte Series para DataFrame se necessario
            if isinstance(dividendos, pd.Series):
                div_series = dividendos
            else:
                # Se vier como DataFrame, pega primeira coluna
                div_series = dividendos.iloc[:, 0] if isinstance(dividendos, pd.DataFrame) else dividendos
            
            # 2. Cria serie diaria de dividendos (sum por dia)
            div_diario = div_series.resample('D').sum()
            
            # 3. Reindex para alinhar com hist
            div_diario = div_diario.reindex(hist.index, fill_value=0)
            
            # 4. Soma rolling de 252 dias (12 meses)
            # IMPORTANTE: Garantir que retorna Series, nao DataFrame
            div_12m = div_diario.rolling(window=252, min_periods=1).sum()
            
            # 5. Pega coluna Close do hist
            # CRITICO: Close pode ser Series ou valor de DataFrame
            if isinstance(hist, pd.DataFrame):
                close_series = hist['Close']
            else:
                close_series = hist
            
            # 6. Calcula DY usando Close NOMINAL (nao ajustado!)
            # Garante que ambos sao Series antes de dividir
            dy_12m = div_12m / close_series
            dy_12m = dy_12m.fillna(0)
            
            # Garante que dy_12m e uma Series
            if isinstance(dy_12m, pd.DataFrame):
                dy_12m = dy_12m.iloc[:, 0]
            
            # Adiciona ao DataFrame
            df_final = hist.copy()
            df_final['dy_12m'] = dy_12m.values  # Usa .values para evitar problemas de index
            
            # Conta dias com DY > 0
            dias_com_dy = (dy_12m > 0).sum()
        
        # Prepara dados para inserir no banco
        registros = []
        
        for data, row in df_final.iterrows():
            # IMPORTANTE:
            # - Open, High, Low, Close = precos NOMINAIS (sem ajuste)
            # - dy_12m = calculado com Close nominal
            # - Adj Close NAO eh salvo no banco (usado apenas para calcular retornos)
            
            # Usa .item() para extrair valor escalar de forma robusta
            registro = {
                "ticker": ticker,
                "data": data.strftime("%Y-%m-%d"),
                "open": row['Open'].item() if hasattr(row['Open'], 'item') else float(row['Open']),
                "high": row['High'].item() if hasattr(row['High'], 'item') else float(row['High']),
                "low": row['Low'].item() if hasattr(row['Low'], 'item') else float(row['Low']),
                "close": row['Close'].item() if hasattr(row['Close'], 'item') else float(row['Close']),
                "volume": int(row['Volume'].item() if hasattr(row['Volume'], 'item') else row['Volume']),
                "dy_12m": row['dy_12m'].item() if hasattr(row['dy_12m'], 'item') else float(row['dy_12m'])
            }
            registros.append(registro)
        
        # Insere no banco
        database = db.get_db()
        database.inserir_precos(registros)
        
        return True, dias_com_dy
    
    except Exception as e:
        print(f"\nErro ao baixar {ticker}: {e}")
        return False, 0


def main():
    parser = argparse.ArgumentParser(description="Download de precos historicos")
    parser.add_argument("--periodo", type=int, default=10,
                       help="Anos de historico (padrao: 10)")
    parser.add_argument("--continuar", action="store_true",
                       help="Pula tickers que ja tem dados")
    parser.add_argument("--delay", type=float, default=0.5,
                       help="Delay entre requests em segundos")
    args = parser.parse_args()
    
    # Carrega universo
    arquivo_universo = CFG["universo"]["arquivo"]
    
    try:
        with open(arquivo_universo, encoding='utf-8') as f:
            tickers = [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print(f"Erro: {arquivo_universo} nao encontrado")
        return
    
    # Database
    database = db.get_db()
    
    print(f"{'='*70}")
    print(f"DOWNLOAD DE PRECOS - UNIVERSO COMPLETO")
    print(f"{'='*70}")
    print(f"Tickers: {len(tickers)}")
    print(f"Periodo: {args.periodo} anos")
    print(f"Continuar: {'Sim' if args.continuar else 'Nao'}")
    print(f"{'='*70}\n")
    print("CORRECOES APLICADAS:")
    print("  [OK] auto_adjust=False (precos nominais)")
    print("  [OK] Close para DY, Adj Close para retornos")
    print("  [OK] Calculo eficiente com rolling window")
    print(f"{'='*70}\n")
    
    # Contadores
    sucesso = 0
    falha = 0
    pulado = 0
    
    # Baixa cada ticker
    for i, ticker in enumerate(tickers, 1):
        print(f"[{i:3d}/{len(tickers)}] {ticker:12s}...", end=" ", flush=True)
        
        # Verifica se ja tem dados
        if args.continuar and verificar_tem_dados(ticker, database):
            print("[OK] (ja tem dados)")
            pulado += 1
            continue
        
        # Baixa
        resultado = baixar_precos_ticker(ticker, anos=args.periodo)
        
        if isinstance(resultado, tuple):
            ok, dias_dy = resultado
            if ok:
                print(f"[OK] ({dias_dy} dias com DY)")
                sucesso += 1
            else:
                print("[X]")
                falha += 1
        else:
            print("[X]")
            falha += 1
        
        # Delay entre requests
        if i < len(tickers):
            time.sleep(args.delay)
    
    # Resumo
    print(f"\n{'='*70}")
    print(f"RESUMO:")
    print(f"  Sucesso: {sucesso}")
    print(f"  Falha: {falha}")
    print(f"  Pulado: {pulado}")
    
    if falha > 0:
        print(f"\n[!] Alguns tickers falharam. Possiveis causas:")
        print(f"  - Ticker incorreto ou deslistado")
        print(f"  - Problema de conexao")
        print(f"  - Rate limit da API")
        print(f"\nTente rodar novamente com --continuar para processar so os faltantes.\n")
    
    print(f"{'='*70}\n")


if __name__ == "__main__":
    main()