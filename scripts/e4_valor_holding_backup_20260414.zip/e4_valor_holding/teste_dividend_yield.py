"""
Teste: Cálculo de Dividend Yield
=================================
Verifica se o cálculo de DY está funcionando.
"""

import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta

print("="*70)
print("TESTE: Cálculo de Dividend Yield")
print("="*70)

# Tickers para testar (sabemos que pagam dividendos)
tickers_teste = ["PETR4.SA", "VALE3.SA", "ITUB4.SA", "BBDC4.SA", "WEGE3.SA"]

for ticker in tickers_teste:
    print(f"\n{ticker}:")
    print("-" * 70)
    
    try:
        # Busca dividendos
        acao = yf.Ticker(ticker)
        dividendos = acao.dividends
        
        if dividendos.empty:
            print("  ✗ Sem dados de dividendos")
            continue
        
        print(f"  ✓ {len(dividendos)} pagamentos de dividendos encontrados")
        print(f"  Período: {dividendos.index.min()} a {dividendos.index.max()}")
        
        # Últimos 5 pagamentos
        print("\n  Últimos 5 pagamentos:")
        ultimos = dividendos.tail(5)
        for data, valor in ultimos.items():
            print(f"    {data.date()}: R$ {valor:.4f}")
        
        # Total últimos 12 meses
        hoje = datetime.now()
        um_ano_atras = hoje - timedelta(days=365)
        
        divs_12m = dividendos[dividendos.index > um_ano_atras]
        total_12m = divs_12m.sum()
        
        print(f"\n  Total últimos 12 meses: R$ {total_12m:.4f}")
        
        # Busca preço atual
        hist = acao.history(period="1d")
        if not hist.empty:
            preco_atual = hist['Close'].iloc[-1]
            dy_atual = (total_12m / preco_atual) * 100
            
            print(f"  Preço atual: R$ {preco_atual:.2f}")
            print(f"  DY atual: {dy_atual:.2f}%")
        
    except Exception as e:
        print(f"  ✗ Erro: {e}")

print("\n" + "="*70)
print("RESUMO")
print("="*70)
print("""
Se aparecerem dividendos acima, o yfinance está funcionando!

PRÓXIMO PASSO:
  python e4_screening.py --ticker PETR4.SA

  Deve aparecer:
    "Calculando DY para PETR4.SA... ✓ (XXX dias, DY médio: X.X%)"

Se não aparecer, há um problema na integração.
""")