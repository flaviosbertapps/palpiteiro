# -*- coding: utf-8 -*-
"""
DEBUG - Testa cálculo de CAGR
"""

import pandas as pd
import numpy as np

# DADOS DE EXEMPLO (baseado nos seus resultados)
trades_exemplo = [
    {"data_entrada": "2015-01-15", "data_saida": "2015-05-10", "retorno_%": 10.5},
    {"data_entrada": "2015-08-20", "data_saida": "2015-12-01", "retorno_%": -5.2},
    {"data_entrada": "2016-03-10", "data_saida": "2016-07-15", "retorno_%": 15.3},
]

df = pd.DataFrame(trades_exemplo)
df["data_entrada"] = pd.to_datetime(df["data_entrada"])
df["data_saida"] = pd.to_datetime(df["data_saida"])

# Parâmetros
capital_inicial = 100000
selic_anual = 0.10
selic_diaria = (1 + selic_anual) ** (1/252) - 1

print("="*70)
print("DEBUG - CALCULO CAGR COM SELIC")
print("="*70)
print(f"Capital inicial: R$ {capital_inicial:,.2f}")
print(f"SELIC anual: {selic_anual*100:.1f}%")
print(f"SELIC diária: {selic_diaria*100:.4f}%")
print(f"Trades: {len(df)}")
print()

# Simula passo a passo
patrimonio = capital_inicial
data_atual = df["data_entrada"].min()

print("SIMULACAO:")
print("-"*70)

for idx, trade in df.iterrows():
    print(f"\nTrade {idx+1}:")
    print(f"  Entrada: {trade['data_entrada'].strftime('%Y-%m-%d')}")
    print(f"  Saida: {trade['data_saida'].strftime('%Y-%m-%d')}")
    print(f"  Retorno: {trade['retorno_%']:+.2f}%")
    
    # Dias parados antes
    dias_parado = (trade["data_entrada"] - data_atual).days
    print(f"  Dias parado antes: {dias_parado}")
    
    if dias_parado > 0:
        patrimonio_antes = patrimonio
        patrimonio *= (1 + selic_diaria) ** dias_parado
        ganho_selic = patrimonio - patrimonio_antes
        print(f"  Ganho SELIC: R$ {ganho_selic:,.2f} ({(patrimonio/patrimonio_antes - 1)*100:.2f}%)")
    
    # Aplica trade
    patrimonio_antes_trade = patrimonio
    patrimonio *= (1 + trade["retorno_%"] / 100)
    ganho_trade = patrimonio - patrimonio_antes_trade
    print(f"  Ganho trade: R$ {ganho_trade:,.2f}")
    print(f"  Patrimonio: R$ {patrimonio:,.2f}")
    
    data_atual = trade["data_saida"]

# Final
data_fim = df["data_saida"].max()
anos = (data_fim - df["data_entrada"].min()).days / 365.25

print(f"\n{'='*70}")
print("RESULTADO FINAL:")
print(f"{'='*70}")
print(f"Patrimonio inicial: R$ {capital_inicial:,.2f}")
print(f"Patrimonio final: R$ {patrimonio:,.2f}")
print(f"Periodo: {anos:.2f} anos")
print(f"Ganho total: {(patrimonio/capital_inicial - 1)*100:.2f}%")

cagr = (patrimonio / capital_inicial) ** (1 / anos) - 1
print(f"CAGR: {cagr*100:.2f}%/ano")

# Compara com métrica antiga
ret_medio = df["retorno_%"].mean()
holding_medio = ((df["data_saida"] - df["data_entrada"]).dt.days).mean()
ret_anual_antigo = ret_medio * (365 / holding_medio)

print(f"\nCOMPARACAO:")
print(f"  Ret medio/trade: {ret_medio:.2f}%")
print(f"  Holding medio: {holding_medio:.0f} dias")
print(f"  Ret Anual (antigo): {ret_anual_antigo:.1f}%")
print(f"  CAGR Real (novo): {cagr*100:.2f}%")
print(f"  Diferenca: {ret_anual_antigo - cagr*100:.1f}pp")
print()