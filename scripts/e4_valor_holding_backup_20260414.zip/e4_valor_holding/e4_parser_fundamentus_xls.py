"""
e4_parser_fundamentus_xls.py - WINDOWS COMPATIBLE
==================================================
Parser de arquivos XLS do Fundamentus usando pandas (sem LibreOffice).

INSTALAÇÃO:
  pip install xlrd openpyxl

WORKFLOW:
1. Baixar balanco.xls do Fundamentus (tem CAPTCHA)
2. python e4_parser_fundamentus_xls.py --ticker CSNA3 --dir ./xls
3. Dados salvos no banco!
"""

import pandas as pd
import os
from datetime import datetime
from typing import Dict, Optional
import json

import e4_database as db

with open("e4_config.json") as f:
    CFG = json.load(f)


# ===========================================================================
# Mapeamento (baseado em CSN)
# ===========================================================================

MAPA_BALANCO = {
    # ATIVO
    "ativo_total": 2,
    "ativo_circulante": 3,
    "caixa_equivalentes": 4,
    "contas_receber": 6,
    "estoques": 7,
    "imobilizado": 21,
    
    # PASSIVO
    "passivo_circulante": 27,
    "emprestimos_cp": 31,           # Curto prazo
    "passivo_nao_circulante": 37,
    "emprestimos_lp": 38,           # Longo prazo
    
    # PATRIMÔNIO LÍQUIDO
    "patrimonio_liquido": 47,
}


# ===========================================================================
# Leitura XLS usando pandas
# ===========================================================================

def ler_xls_fundamentus(xls_path: str) -> pd.DataFrame:
    """
    Lê arquivo XLS do Fundamentus usando pandas.
    
    IMPORTANTE: Precisa ter xlrd instalado
      pip install xlrd
    
    Args:
        xls_path: Caminho do balanco.xls
    
    Returns:
        DataFrame pivotado [datas como index, indicadores como colunas]
    """
    try:
        # Tenta com xlrd (XLS antigo)
        df_raw = pd.read_excel(xls_path, engine='xlrd', header=None)
    except Exception as e1:
        try:
            # Tenta com openpyxl (XLSX)
            df_raw = pd.read_excel(xls_path, engine='openpyxl', header=None)
        except Exception as e2:
            raise Exception(f"Erro ao ler XLS. Instale: pip install xlrd openpyxl\n{e1}\n{e2}")
    
    # Linha 1 = datas (formato: 31/12/2010)
    datas_raw = df_raw.iloc[1].tolist()
    
    datas = []
    for d in datas_raw:
        if pd.isna(d):
            continue
        
        try:
            # Tenta parsear como string
            if isinstance(d, str):
                data = datetime.strptime(d, "%d/%m/%Y").strftime("%Y-%m-%d")
            # Tenta parsear como datetime (Excel pode converter)
            elif isinstance(d, (pd.Timestamp, datetime)):
                data = d.strftime("%Y-%m-%d")
            else:
                continue
            
            datas.append(data)
        except:
            continue
    
    # Linhas 2+ = dados
    dados = {}
    
    for i in range(2, len(df_raw)):
        valores = df_raw.iloc[i].tolist()[:len(datas)]
        
        # Converte para float
        valores_float = []
        for v in valores:
            try:
                valores_float.append(float(v) if not pd.isna(v) else None)
            except:
                valores_float.append(None)
        
        dados[f"linha_{i}"] = valores_float
    
    # Cria DataFrame
    df = pd.DataFrame(dados, index=datas)
    df.index.name = "data"
    
    return df


def extrair_indicador(df: pd.DataFrame, linha_idx: int) -> pd.Series:
    """Extrai uma linha específica do DataFrame"""
    coluna = f"linha_{linha_idx}"
    
    if coluna in df.columns:
        return df[coluna]
    
    return pd.Series(dtype=float)


# ===========================================================================
# Parser principal
# ===========================================================================

def processar_ticker(ticker_base: str, dir_xls: str) -> bool:
    """
    Processa arquivo XLS de um ticker.
    
    Args:
        ticker_base: Ticker SEM .SA (ex: CSNA3)
        dir_xls: Diretório com o arquivo
    
    Returns:
        True se sucesso
    """
    ticker = f"{ticker_base}.SA"
    
    print(f"\n{'='*70}")
    print(f"Processando {ticker}")
    print(f"{'='*70}\n")
    
    # Localiza arquivo balanco.xls
    balanco_xls = os.path.join(dir_xls, f"balanco_{ticker_base}.xls")
    
    if not os.path.exists(balanco_xls):
        print(f"✗ {balanco_xls} não encontrado")
        print(f"\nBAIXE MANUALMENTE:")
        print(f"https://fundamentus.com.br/balancos.php?papel={ticker_base}")
        return False
    
    # Lê XLS diretamente com pandas
    print(f"1. Lendo XLS com pandas...")
    
    try:
        df = ler_xls_fundamentus(balanco_xls)
        print(f"   ✓ {len(df)} trimestres, {len(df.columns)} linhas")
    except Exception as e:
        print(f"   ✗ Erro: {e}")
        print(f"\nINSTALE:")
        print(f"  pip install xlrd")
        return False
    
    # Extrai dados
    print(f"\n2. Extraindo indicadores...")
    
    dados_por_data = {}
    
    for data in df.index:
        dados_por_data[data] = {
            "ticker": ticker,
            "data": data,
        }
        
        for nome, linha_idx in MAPA_BALANCO.items():
            serie = extrair_indicador(df, linha_idx)
            
            if data in serie.index:
                dados_por_data[data][nome] = serie[data]
    
    print(f"   ✓ {len(dados_por_data)} snapshots")
    
    # Calcula indicadores derivados
    print(f"\n3. Calculando indicadores derivados...")
    
    for data, registro in dados_por_data.items():
        # Dívida Bruta
        emp_cp = registro.get("emprestimos_cp", 0) or 0
        emp_lp = registro.get("emprestimos_lp", 0) or 0
        divida_bruta = emp_cp + emp_lp
        
        # Patrimônio Líquido
        patrim_liq = registro.get("patrimonio_liquido", 1) or 1
        
        # Liquidez Corrente
        ativo_c = registro.get("ativo_circulante", 0) or 0
        passivo_c = registro.get("passivo_circulante", 1) or 1
        liq_corrente = ativo_c / passivo_c if passivo_c else None
        
        # Dívida Bruta / Patrimônio
        div_brut_patrim = divida_bruta / patrim_liq if patrim_liq else None
        
        # Atualiza com campos do banco
        campos_banco = {
            "ticker": ticker,
            "data": data,
            "liq_corrente": liq_corrente,
            "div_brut_patrim": div_brut_patrim,
            # Campos que virão depois
            "p_l": None,
            "p_vp": None,
            "dy": None,
            "roe": None,
            "roic": None,
            "p_ebit": None,
            "p_ativo": None,
            "p_cap_giro": None,
            "margem_bruta": None,
            "margem_ebit": None,
            "margem_liquida": None,
        }
        
        dados_por_data[data] = campos_banco
    
    print(f"   ✓ Liquidez, endividamento, etc.")
    
    # Salva no banco
    print(f"\n4. Salvando no banco de dados...")
    
    database = db.get_db()
    registros = list(dados_por_data.values())
    database.inserir_fundamentalista(registros)
    
    print(f"   ✓ {len(registros)} registros salvos")
    
    print(f"\n{'='*70}")
    print(f"✓ {ticker} processado com sucesso!")
    print(f"{'='*70}\n")
    
    return True


# ===========================================================================
# CLI
# ===========================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Parser XLS Fundamentus (Windows/Linux)"
    )
    parser.add_argument("--ticker", required=True, help="Ticker (ex: CSNA3)")
    parser.add_argument("--dir", default="fundamentos", help="Diretório dos XLS")
    
    args = parser.parse_args()
    
    sucesso = processar_ticker(args.ticker, args.dir)
    
    if not sucesso:
        exit(1)