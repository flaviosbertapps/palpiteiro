"""
Estratégia: Valor - Saída Fundamentalista
==========================================
Compra papéis baratos e vende quando fundamentalistas deterioram.

Hipótese: Melhor sair quando P/L > 12 ou ROE < 10% (retornou à média).
"""

import pandas as pd
import json

with open("e4_config.json") as f:
    CFG = json.load(f)


PARAMETROS = {
    # Critérios de entrada
    "p_l_max": 8,
    "p_l_min": 0,
    "dy_min": 0.06,
    "roe_min": 0.15,
    "p_vp_max": 1.5,
    "liquidez_min_diaria": 1_000_000,
    
    # Critérios de saída
    "p_l_saida": 12,          # Vende quando P/L > 12 (retornou à média)
    "roe_saida": 0.10,        # Vende quando ROE < 10% (deteriorou)
    "holding_max_meses": 24,  # Força saída após 24m
}


def fn_sinal(row: pd.Series, p: dict) -> bool:
    """Detecta papéis de valor"""
    try:
        p_l = row.get("p_l")
        dy = row.get("dy")
        roe = row.get("roe")
        p_vp = row.get("p_vp")
        vol_med = row.get("vol_med_2m")
        
        if pd.isna(p_l) or pd.isna(dy) or pd.isna(roe) or pd.isna(p_vp):
            return False
        
        return (
            p["p_l_min"] < p_l <= p["p_l_max"]
            and dy >= p["dy_min"]
            and roe >= p["roe_min"]
            and p_vp <= p["p_vp_max"]
            and (vol_med or 0) >= p["liquidez_min_diaria"]
        )
    except Exception:
        return False


def fn_saida(data_entrada: pd.Timestamp, dias_posicao: int,
             preco_entrada: float, preco_atual: float,
             row_atual: pd.Series, p: dict) -> tuple:
    """
    Saída quando fundamentalistas deterioram.
    
    Nota: row_atual contém dados fundamentalistas atualizados (se disponíveis)
    """
    # Verifica deterioração fundamentalista
    p_l_atual = row_atual.get("p_l") if row_atual is not None else None
    roe_atual = row_atual.get("roe") if row_atual is not None else None
    
    if p_l_atual is not None and p_l_atual > p["p_l_saida"]:
        return (True, "p_l_alto")
    
    if roe_atual is not None and roe_atual < p["roe_saida"]:
        return (True, "roe_baixo")
    
    # Holding máximo
    if dias_posicao >= p["holding_max_meses"] * 30:
        return (True, "tempo_max")
    
    return (False, None)


ESTRATEGIA = {
    "nome": "valor_fundamentalista",
    "descricao": "Valor com saída por deterioração de P/L ou ROE",
    "parametros": PARAMETROS,
    "fn_sinal": fn_sinal,
    "fn_saida": fn_saida,
}
