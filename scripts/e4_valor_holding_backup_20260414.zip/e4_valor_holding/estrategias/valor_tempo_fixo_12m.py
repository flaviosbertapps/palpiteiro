"""
Estratégia: Valor - Tempo Fixo 12 Meses
========================================
Compra papéis baratos e segura exatamente 12 meses.

Hipótese: Reversão à média acontece em ~12 meses.
"""

import pandas as pd
import json

# Carregar configuração
with open("e4_config.json") as f:
    CFG = json.load(f)


# ===========================================================================
# Parâmetros
# ===========================================================================

PARAMETROS = {
    # Critérios de entrada (valor)
    "p_l_max": 8,
    "p_l_min": 0,
    "dy_min": 0.06,
    "roe_min": 0.15,
    "p_vp_max": 1.5,
    "liquidez_min_diaria": 1_000_000,
    
    # Critério de saída
    "holding_meses": 12,
}


# ===========================================================================
# Função de sinal (entrada)
# ===========================================================================

def fn_sinal(row: pd.Series, p: dict) -> bool:
    """
    Detecta se o papel atende critérios de valor.
    
    Args:
        row: Linha do DataFrame com dados fundamentalistas
        p: Dicionário de parâmetros
    
    Returns:
        True se atende critérios de valor
    """
    try:
        p_l = row.get("p_l")
        dy = row.get("dy")
        roe = row.get("roe")
        p_vp = row.get("p_vp")
        vol_med = row.get("vol_med_2m")
        
        # Validações básicas
        if pd.isna(p_l) or pd.isna(dy) or pd.isna(roe) or pd.isna(p_vp):
            return False
        
        # Aplica critérios
        return (
            p["p_l_min"] < p_l <= p["p_l_max"]
            and dy >= p["dy_min"]
            and roe >= p["roe_min"]
            and p_vp <= p["p_vp_max"]
            and (vol_med or 0) >= p["liquidez_min_diaria"]
        )
    
    except Exception:
        return False


# ===========================================================================
# Função de saída
# ===========================================================================

def fn_saida(data_entrada: pd.Timestamp, dias_posicao: int, 
             preco_entrada: float, preco_atual: float,
             row_atual: pd.Series, p: dict) -> tuple:
    """
    Determina se deve sair da posição.
    
    Args:
        data_entrada: Data da compra
        dias_posicao: Dias desde a compra
        preco_entrada: Preço de entrada
        preco_atual: Preço atual
        row_atual: Linha atual com dados fundamentalistas (se disponível)
        p: Parâmetros
    
    Returns:
        (deve_sair: bool, motivo: str)
    """
    # Sai após holding_meses
    if dias_posicao >= p["holding_meses"] * 30:
        return (True, "tempo_fixo")
    
    return (False, None)


# ===========================================================================
# Dicionário exportado (interface com screening)
# ===========================================================================

ESTRATEGIA = {
    "nome": "valor_tempo_fixo_12m",
    "descricao": "Valor com holding fixo de 12 meses",
    "parametros": PARAMETROS,
    "fn_sinal": fn_sinal,
    "fn_saida": fn_saida,
}
