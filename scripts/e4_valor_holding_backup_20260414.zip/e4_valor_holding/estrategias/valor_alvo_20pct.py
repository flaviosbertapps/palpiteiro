"""
Estratégia: Valor - Alvo 20%
=============================
Compra papéis baratos e vende quando atingir +20% ou após 24 meses.

Hipótese: Maioria dos papéis reverte rapidamente (+20% em 6-12m).
"""

import pandas as pd
import json

with open("e4_config.json") as f:
    CFG = json.load(f)


PARAMETROS = {
    # Critérios de entrada
    "p_l_max": 8,
    "p_l_min": 0,
    "dy_min": 0.06,
    "roe_min": 0.15,
    "p_vp_max": 1.5,
    "liquidez_min_diaria": 1_000_000,
    
    # Critério de saída
    "alvo_pct": 0.20,        # Vende ao bater +20%
    "holding_max_meses": 24,  # Força saída após 24m
}


def fn_sinal(row: pd.Series, p: dict) -> bool:
    """Detecta papéis de valor (mesma lógica do tempo_fixo_12m)"""
    try:
        p_l = row.get("p_l")
        dy = row.get("dy")
        roe = row.get("roe")
        p_vp = row.get("p_vp")
        vol_med = row.get("vol_med_2m")
        
        if pd.isna(p_l) or pd.isna(dy) or pd.isna(roe) or pd.isna(p_vp):
            return False
        
        return (
            p["p_l_min"] < p_l <= p["p_l_max"]
            and dy >= p["dy_min"]
            and roe >= p["roe_min"]
            and p_vp <= p["p_vp_max"]
            and (vol_med or 0) >= p["liquidez_min_diaria"]
        )
    except Exception:
        return False


def fn_saida(data_entrada: pd.Timestamp, dias_posicao: int,
             preco_entrada: float, preco_atual: float,
             row_atual: pd.Series, p: dict) -> tuple:
    """
    Saída por alvo ou tempo máximo.
    """
    # Calcula ganho
    ganho_pct = (preco_atual / preco_entrada) - 1
    
    # Atingiu alvo?
    if ganho_pct >= p["alvo_pct"]:
        return (True, "alvo")
    
    # Atingiu holding máximo?
    if dias_posicao >= p["holding_max_meses"] * 30:
        return (True, "tempo_max")
    
    return (False, None)


ESTRATEGIA = {
    "nome": "valor_alvo_20pct",
    "descricao": "Valor com saída em +20% ou 24 meses",
    "parametros": PARAMETROS,
    "fn_sinal": fn_sinal,
    "fn_saida": fn_saida,
}
