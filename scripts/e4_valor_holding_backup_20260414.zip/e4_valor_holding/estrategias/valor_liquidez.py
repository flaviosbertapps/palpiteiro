"""
Estratégia: Valor Liquidez (SEM DRE)
====================================
Baseada APENAS em dados do Balanço Patrimonial.

Hipótese: Empresas com boa liquidez e baixo endividamento tendem
          a ter desempenho superior no médio prazo.

Status: ✅ FUNCIONA COM DADOS DISPONÍVEIS

Dados necessários: Apenas balanco.xls (já temos!)
"""

import pandas as pd
import numpy as np
import json

with open("e4_config.json") as f:
    CFG = json.load(f)


# ===========================================================================
# Parâmetros
# ===========================================================================

PARAMETROS = {
    # --- Entrada (critérios de balanço) ---
    "liq_corrente_min": 1.5,      # Liquidez >= 1.5 (empresa saudável)
    "liq_corrente_max": 5.0,      # Liquidez <= 5.0 (não excessiva)
    
    "div_brut_patrim_max": 2.0,   # Dívida/PL <= 2.0 (endividamento controlado)
    
    # --- Saída ---
    "holding_meses": 12,           # Holding fixo 12 meses
    "alvo_pct": 0.25,              # OU +25% (o que vier primeiro)
}


# ===========================================================================
# Helpers
# ===========================================================================

def _val(row: pd.Series, col: str, default=np.nan):
    """Extrai valor de uma Series com fallback"""
    v = row.get(col, default)
    return default if pd.isna(v) else v


# ===========================================================================
# Função de sinal (entrada)
# ===========================================================================

def fn_sinal(row: pd.Series, p: dict) -> bool:
    """
    Detecta se o papel atende critérios de liquidez e endividamento.
    
    Args:
        row: Linha do DataFrame com dados fundamentalistas
        p: Dicionário de parâmetros
    
    Returns:
        True se atende critérios
    """
    try:
        # Extrai valores
        liq_corrente = _val(row, "liq_corrente")
        div_brut_patrim = _val(row, "div_brut_patrim")
        
        # Validações básicas
        if pd.isna(liq_corrente) or pd.isna(div_brut_patrim):
            return False
        
        # Aplica critérios
        return (
            # Liquidez saudável mas não excessiva
            p["liq_corrente_min"] <= liq_corrente <= p["liq_corrente_max"]
            
            # Endividamento controlado
            and div_brut_patrim <= p["div_brut_patrim_max"]
        )
    
    except Exception:
        return False


# ===========================================================================
# Função de saída
# ===========================================================================

def fn_saida(data_entrada: pd.Timestamp, dias_posicao: int,
             preco_entrada: float, preco_atual: float,
             row_atual: pd.Series, p: dict) -> tuple:
    """
    Determina se deve sair da posição.
    
    Saída por:
      1. Holding máximo (12 meses)
      2. Alvo de ganho (+25%)
    
    Returns:
        (deve_sair: bool, motivo: str)
    """
    # Calcula ganho
    ganho_pct = (preco_atual / preco_entrada) - 1
    
    # Atingiu alvo?
    if ganho_pct >= p["alvo_pct"]:
        return (True, "alvo")
    
    # Atingiu holding máximo?
    if dias_posicao >= p["holding_meses"] * 30:
        return (True, "tempo")
    
    return (False, None)


# ===========================================================================
# Dicionário exportado (interface com screening)
# ===========================================================================

ESTRATEGIA = {
    "nome": "valor_liquidez",
    "descricao": "Valor baseado em liquidez e endividamento (sem DRE)",
    "parametros": PARAMETROS,
    "fn_sinal": fn_sinal,
    "fn_saida": fn_saida,
    "requer_features_tecnicas": False,  # Usa fundamentalista
}