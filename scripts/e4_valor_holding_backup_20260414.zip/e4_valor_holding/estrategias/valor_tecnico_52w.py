"""
Estratégia: Valor Técnico 52 Semanas (OTIMIZADA)
=================================================
Compra papéis que caíram significativamente do topo de 52 semanas,
com RSI sobrevendido.

Status: ✅ PRODUÇÃO-READY (sem look-ahead bias, com stop loss)

Hipótese: Papéis de qualidade que caem 35%+ do topo de 52w
          tendem a reverter à média em 6-12 meses.

Dados necessários: Apenas preços (yfinance)

Melhorias v2:
- Stop loss -25% (proteção de capital)
- Filtros de qualidade (preço min, liquidez)
- Critérios mais rígidos (RSI < 25, queda > 35%)
- Parâmetros otimizados
"""

import pandas as pd
import numpy as np
import json

with open("e4_config.json") as f:
    CFG = json.load(f)


# ===========================================================================
# Parâmetros
# ===========================================================================

PARAMETROS = {
    # --- Entrada (critérios técnicos) ---
    "preco_vs_max_52w_max": 0.70,   # Preço <= 70% da máxima 52w (caiu 30%+)
    "preco_vs_max_52w_min": 0.55,   # Preço >= 55% da máxima (evita colapsos)
    
    "rsi_max": 28,                   # RSI < 28 (sobrevendido)
    "rsi_min": 20,                   # RSI > 20 (evita pânicos extremos)
    
    "vol_relativo_min": 1.2,         # Volume >= 1.2x média (interesse acima da média)
    
    # Dividendos (opcional - 0 = ignora)
    "dy_12m_min": 0.00,              # Dividend Yield mínimo
    
    # Qualidade do papel
    "vol_financeiro_min": 1_500_000, # R$ 1.5mi/dia mínimo (liquidez)
    "preco_min": 3.0,                # Evita penny stocks (< R$ 3)
    
    # --- Saída ---
    "holding_meses": 12,              # Holding máximo 12 meses
    "alvo_pct": 0.30,                 # Alvo +30%
    "stop_loss_pct": -0.28,           # Stop loss -28%
}


# ===========================================================================
# Helpers
# ===========================================================================

def _val(row: pd.Series, col: str, default=np.nan):
    """Extrai valor de uma Series com fallback"""
    v = row.get(col, default)
    return default if pd.isna(v) else v


# ===========================================================================
# Função de sinal (entrada)
# ===========================================================================

def fn_sinal(row: pd.Series, p: dict) -> bool:
    """
    Detecta se o papel atende critérios técnicos de valor.
    
    Args:
        row: Linha do DataFrame com features técnicas
        p: Dicionário de parâmetros
    
    Returns:
        True se atende critérios
    """
    try:
        # Extrai valores
        preco_vs_max = _val(row, "preco_vs_max_52w")
        rsi = _val(row, "rsi")
        vol_rel = _val(row, "vol_relativo")
        vol_fin = _val(row, "vol_financeiro")
        dy_12m = _val(row, "dy_12m", 0)
        close = _val(row, "close")
        
        # Validações básicas
        if pd.isna(preco_vs_max) or pd.isna(rsi) or pd.isna(close):
            return False
        
        # Aplica critérios
        return (
            # Preço caiu significativamente do topo (35-50%)
            p["preco_vs_max_52w_min"] <= preco_vs_max <= p["preco_vs_max_52w_max"]
            
            # RSI muito sobrevendido (20-25)
            and p["rsi_min"] <= rsi <= p["rsi_max"]
            
            # Volume forte (>= 1.5x média)
            and vol_rel >= p["vol_relativo_min"]
            
            # Liquidez mínima (R$ 2mi/dia)
            and vol_fin >= p["vol_financeiro_min"]
            
            # Evita penny stocks (>= R$ 5)
            and close >= p["preco_min"]
            
            # Dividendos (opcional, 0 = ignora)
            and dy_12m >= p["dy_12m_min"]
        )
    
    except Exception:
        return False


# ===========================================================================
# Função de saída
# ===========================================================================

def fn_saida(data_entrada: pd.Timestamp, dias_posicao: int,
             preco_entrada: float, preco_atual: float,
             row_atual: pd.Series, p: dict) -> tuple:
    """
    Determina se deve sair da posição.
    
    Saída por:
      1. Stop loss -25% (proteção!)
      2. Alvo de ganho +35%
      3. Holding máximo 12 meses
    
    Returns:
        (deve_sair: bool, motivo: str)
    """
    # Calcula ganho
    ganho_pct = (preco_atual / preco_entrada) - 1
    
    # 1. STOP LOSS -25% (PRIMEIRO - protege capital!)
    if ganho_pct <= p["stop_loss_pct"]:
        return (True, "stop_loss")
    
    # 2. Atingiu alvo +35%?
    if ganho_pct >= p["alvo_pct"]:
        return (True, "alvo")
    
    # 3. Atingiu holding máximo (12 meses)?
    if dias_posicao >= p["holding_meses"] * 30:
        return (True, "tempo")
    
    return (False, None)


# ===========================================================================
# Dicionário exportado (interface com screening)
# ===========================================================================

ESTRATEGIA = {
    "nome": "valor_tecnico_52w",
    "descricao": "Valor técnico: preço vs máxima 52w + RSI (com stop loss)",
    "parametros": PARAMETROS,
    "fn_sinal": fn_sinal,
    "fn_saida": fn_saida,
    "requer_features_tecnicas": True,  # Flag para o screening processar
}