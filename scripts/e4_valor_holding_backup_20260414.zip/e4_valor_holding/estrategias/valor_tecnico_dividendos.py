"""
Estratégia: Valor Técnico 52w + Dividendos
===========================================
Igual à valor_tecnico_52w mas EXIGE dividendos > 3%

Hipótese: Papéis que pagam dividendos são de melhor qualidade
          e têm menor risco de colapso.

Comparação: Rode ambas para ver o impacto do filtro DY
"""

import pandas as pd
import numpy as np
import json

with open("e4_config.json") as f:
    CFG = json.load(f)


PARAMETROS = {
    # --- Entrada (critérios técnicos) ---
    "preco_vs_max_52w_max": 0.65,   # Preço <= 70% da máxima 52w (caiu 30%+)
    "preco_vs_max_52w_min": 0.55,   # Preço >= 55% da máxima (evita colapsos)
    
    "rsi_max": 26,                   # RSI < 28 (sobrevendido)
    "rsi_min": 20,                   # RSI > 20 (evita pânicos extremos)
    
    "vol_relativo_min": 1.2,         # Volume >= 1.2x média
    
    # DIFERENÇA: Exige dividendos!
    "dy_12m_min": 0.05,              # DY >= 3% (pagadores de dividendos)
    
    # Qualidade do papel
    "vol_financeiro_min": 2_500_000, # R$ 2.5mi/dia mínimo
    "preco_min": 3.0,                # Evita penny stocks
    
    # --- Saída ---
    "holding_meses": 12,
    "alvo_pct": 0.30,
    "stop_loss_pct": -0.15,

}


def _val(row: pd.Series, col: str, default=np.nan):
    """Extrai valor de uma Series com fallback"""
    v = row.get(col, default)
    return default if pd.isna(v) else v


def fn_sinal(row: pd.Series, p: dict) -> bool:
    """Detecta sinais com FILTRO de dividendos"""
    try:
        preco_vs_max = _val(row, "preco_vs_max_52w")
        rsi = _val(row, "rsi")
        vol_rel = _val(row, "vol_relativo")
        vol_fin = _val(row, "vol_financeiro")
        dy_12m = _val(row, "dy_12m", 0)
        close = _val(row, "close")
        
        if pd.isna(preco_vs_max) or pd.isna(rsi) or pd.isna(close):
            return False
        
        return (
            p["preco_vs_max_52w_min"] <= preco_vs_max <= p["preco_vs_max_52w_max"]
            and p["rsi_min"] <= rsi <= p["rsi_max"]
            and vol_rel >= p["vol_relativo_min"]
            and vol_fin >= p["vol_financeiro_min"]
            and close >= p["preco_min"]
            and dy_12m >= p["dy_12m_min"]  # FILTRO DY!
        )
    
    except Exception:
        return False


def fn_saida(data_entrada: pd.Timestamp, dias_posicao: int,
             preco_entrada: float, preco_atual: float,
             row_atual: pd.Series, p: dict) -> tuple:
    """Mesma saída da estratégia original"""
    ganho_pct = (preco_atual / preco_entrada) - 1
    
    if ganho_pct <= p["stop_loss_pct"]:
        return (True, "stop_loss")
    
    if ganho_pct >= p["alvo_pct"]:
        return (True, "alvo")
    
    if dias_posicao >= p["holding_meses"] * 30:
        return (True, "tempo")
    
    return (False, None)


ESTRATEGIA = {
    "nome": "valor_tecnico_dividendos",
    "descricao": "Valor técnico + filtro DY >= 3%",
    "parametros": PARAMETROS,
    "fn_sinal": fn_sinal,
    "fn_saida": fn_saida,
    "requer_features_tecnicas": True,
}