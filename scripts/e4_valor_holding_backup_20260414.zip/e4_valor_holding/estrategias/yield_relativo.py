"""
Estratégia: Valor Técnico 52w + Dividendos
===========================================
Igual à valor_tecnico_52w mas EXIGE dividendos > 3%

Hipótese: Papéis que pagam dividendos são de melhor qualidade
          e têm menor risco de colapso.

Comparação: Rode ambas para ver o impacto do filtro DY
"""

import pandas as pd
import numpy as np
import json

with open("e4_config.json") as f:
    CFG = json.load(f)


PARAMETROS = {
    "dy_zscore_min": 3.5,            # DY deve estar 2 desvios acima da média (Barato!) 
    "distancia_sma20_max": 0.05,     # Preço não pode estar mais de 5% abaixo da média 20 
    "vol_financeiro_min": 20_000_000,
    
    "holding_dias_max": 120,         # 4 meses de paciência 
    "alvo_pct": 0.20,                # Busca a reversão à média 
    "stop_loss_pct": -0.12,          # Stop mais técnico e curto 
}


def _val(row: pd.Series, col: str, default=np.nan):
    """Extrai valor de uma Series com fallback"""
    v = row.get(col, default)
    return default if pd.isna(v) else v


def fn_sinal(row, p):
    # Só entra se o "sangramento" parou (Preço cruzando ou perto da média 50)
    tendencia_ok = row['close'] >= row['sma_50']
    
    return (
        row['dy_zscore'] >= p["dy_zscore_min"] and 
        tendencia_ok and
        row['vol_financeiro'] >= p["vol_financeiro_min"]
    )


def fn_saida(data_entrada: pd.Timestamp, dias_posicao: int,
             preco_entrada: float, preco_atual: float,
             row_atual: pd.Series, p: dict) -> tuple:
    """Mesma saída da estratégia original"""
    ganho_pct = (preco_atual / preco_entrada) - 1
    
    if ganho_pct <= p["stop_loss_pct"]:
        return (True, "stop_loss")
    
    if ganho_pct >= p["alvo_pct"]:
        return (True, "alvo")
    
    if dias_posicao >= p["holding_meses"] * 30:
        return (True, "tempo")
    
    return (False, None)


ESTRATEGIA = {
    "nome": "yield_relativo",
    "descricao": "Valor técnico + filtro DY >= 3%",
    "parametros": PARAMETROS,
    "fn_sinal": fn_sinal,
    "fn_saida": fn_saida,
    "requer_features_tecnicas": True,
}