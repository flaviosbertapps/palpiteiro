"""
Investigação: Por que não há trades de 2025?
=============================================
"""

import sqlite3
import pandas as pd
import json

print("="*70)
print("INVESTIGAÇÃO: Trades de 2025")
print("="*70)

# Carrega config
with open("e4_config.json") as f:
    CFG = json.load(f)

# Conecta ao banco
conn = sqlite3.connect("data/precos.db")

print("\n1. VERIFICANDO DADOS DE 2025 NO BANCO")
print("-" * 70)

# Conta dias de 2025 por ticker
query = """
SELECT ticker, 
       COUNT(*) as dias_2025,
       MIN(data) as primeira_data,
       MAX(data) as ultima_data
FROM precos
WHERE data >= '2025-01-01'
GROUP BY ticker
ORDER BY ticker
"""

df = pd.read_sql(query, conn)

if df.empty:
    print("❌ SEM DADOS DE 2025 NO BANCO!")
    print("   O banco só tem dados até 2024!")
    print("\n   SOLUÇÃO:")
    print("   python e4_baixar_todos_precos.py")
else:
    print(f"✓ {len(df)} tickers têm dados de 2025")
    print(f"\nPrimeiros 10 tickers:")
    print(df.head(10).to_string(index=False))
    
    # Verifica última data
    ultima = df['ultima_data'].max()
    print(f"\nÚltima data no banco: {ultima}")
    
    if ultima < '2026-03-19':
        print(f"⚠️ Dados estão DESATUALIZADOS!")
        print(f"   Hoje: 2026-03-19")
        print(f"   Último dado: {ultima}")
        print(f"\n   SOLUÇÃO:")
        print(f"   python e4_baixar_todos_precos.py --continuar")

print("\n2. VERIFICANDO SINAIS EM 2025")
print("-" * 70)

# Vamos simular manualmente alguns tickers
tickers_teste = ['PETR4.SA', 'VALE3.SA', 'ITUB4.SA', 'BBDC4.SA']

for ticker in tickers_teste:
    print(f"\n{ticker}:")
    
    # Busca dados de 2025
    query = f"""
    SELECT data, close, dy_12m
    FROM precos
    WHERE ticker = '{ticker}'
      AND data >= '2025-01-01'
      AND data <= '2026-03-19'
    ORDER BY data
    """
    
    df_ticker = pd.read_sql(query, conn)
    
    if df_ticker.empty:
        print(f"  ✗ Sem dados de 2025")
        continue
    
    print(f"  ✓ {len(df_ticker)} dias em 2025-2026")
    print(f"  Período: {df_ticker['data'].min()} a {df_ticker['data'].max()}")
    print(f"  Preço atual: R$ {df_ticker['close'].iloc[-1]:.2f}")
    print(f"  DY médio: {df_ticker['dy_12m'].mean()*100:.2f}%")
    
    # Verifica se DY >= 4%
    tem_dy = (df_ticker['dy_12m'] >= 0.04).sum()
    print(f"  Dias com DY >= 4%: {tem_dy} de {len(df_ticker)}")

conn.close()

print("\n" + "="*70)
print("DIAGNÓSTICO")
print("="*70)

print("""
POSSÍVEIS CAUSAS:

1. Banco sem dados de 2025:
   → Rode: python e4_baixar_todos_precos.py
   
2. Banco desatualizado (só até Dez/2025):
   → Rode: python e4_baixar_todos_precos.py --continuar
   
3. Nenhum papel atendeu critérios em 2025:
   → RSI < 28
   → Preço caiu 30-50% do topo
   → Volume > 1.2x média
   → DY >= 4%
   → Liquidez >= R$ 2.5mi/dia
   
   Pode ser que 2025 foi um ano bom (mercado subindo)
   e não houve oportunidades de "comprar quedas"!

4. Houve sinais mas trades não completaram:
   → Veja mensagem "[DEBUG ...]" no screening
   → Pode ter entradas em Jan/Fev que ainda não saíram
""")