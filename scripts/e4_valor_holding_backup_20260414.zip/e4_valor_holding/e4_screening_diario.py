# -*- coding: utf-8 -*-
"""
e4_screening_diario.py
======================
Sistema de screening diario para deteccao de sinais de compra.

Executar apos o fechamento do mercado (apos 18h).

Workflow:
1. Atualiza banco de dados (precos + dividendos)
2. Detecta sinais de compra nas estrategias ativas
3. Envia e-mail com resumo

Uso:
    python e4_screening_diario.py           # Execucao normal
    python e4_screening_diario.py --dry-run # Teste sem enviar e-mail
"""

import sys
import os

# SOLUCAO ROBUSTA PARA WINDOWS
if sys.platform == 'win32':
    try:
        import io
        if sys.stdout.encoding != 'cp1252':
            sys.stdout = io.TextIOWrapper(
                sys.stdout.buffer, 
                encoding='cp1252', 
                errors='replace',
                line_buffering=True
            )
        if sys.stderr.encoding != 'cp1252':
            sys.stderr = io.TextIOWrapper(
                sys.stderr.buffer, 
                encoding='cp1252', 
                errors='replace',
                line_buffering=True
            )
    except (AttributeError, ValueError):
        pass

import json
import argparse
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
import pandas as pd
import e4_screening as screening
import e4_database as db_module
import utils

# ============================================================================
# CONFIGURACAO
# ============================================================================

# Carrega config
with open("e4_config.json", encoding='utf-8') as f:
    CFG = json.load(f)

# Instancia database
db = db_module.get_db()

# Config de e-mail (CONFIGURE AQUI!)
EMAIL_CONFIG = {
    "remetente": "seu_email@gmail.com",  # <- CONFIGURE!
    "destinatario": "seu_email@gmail.com",  # <- CONFIGURE!
    "assunto_padrao": "[E4] Screening - Sinais de Compra"
}


# ============================================================================
# ETAPA 1: ATUALIZAR BANCO DE DADOS
# ============================================================================

def atualizar_banco_dados(verbose=True):
    """
    Atualiza banco de dados com precos e dividendos mais recentes.
    
    Usa e4_baixar_todos_precos.py com --continuar para apenas
    baixar dados novos desde a ultima atualizacao.
    
    Returns:
        tuple: (sucesso, mensagem)
    """
    if verbose:
        print("\n" + "="*70)
        print("ETAPA 1: Atualizando banco de dados")
        print("="*70)
    
    try:
        # Executa script de download
        resultado = subprocess.run(
            ["python", "e4_baixar_todos_precos.py", "--continuar"],
            capture_output=True,
            text=True,
            timeout=600  # 10 minutos timeout
        )
        
        if resultado.returncode == 0:
            if verbose:
                print("[OK] Banco de dados atualizado")
            return True, "Banco atualizado"
        else:
            erro = resultado.stderr or resultado.stdout
            if verbose:
                print("[X] Erro ao atualizar banco")
            return False, f"Erro: {erro}"
    
    except subprocess.TimeoutExpired:
        if verbose:
            print("[X] Timeout ao atualizar banco (>10 minutos)")
        return False, "Timeout"
    
    except Exception as e:
        if verbose:
            print("[X] Erro ao atualizar banco: {}".format(str(e)))
        return False, str(e)


# ============================================================================
# ETAPA 2: DETECTAR SINAIS DE COMPRA
# ============================================================================

def detectar_sinais_hoje(verbose=True):
    """
    Detecta sinais de compra para HOJE (ultima data disponivel no banco).
    
    Returns:
        list: Lista de dicionarios com sinais detectados
    """
    if verbose:
        print("\n" + "="*70)
        print("ETAPA 2: Detectando sinais de compra")
        print("="*70)
    
    # Conecta ao banco SQLite diretamente para pegar ultima data
    import sqlite3
    conn = sqlite3.connect(CFG["database"]["precos_db"])
    
    # Pega ultima data disponivel
    query_ultima_data = "SELECT MAX(data) as ultima FROM precos"
    df_ultima = pd.read_sql(query_ultima_data, conn)
    data_hoje = df_ultima['ultima'].iloc[0]
    
    if verbose:
        print("Data de referencia: {}".format(data_hoje))
    
    # Carrega universo de tickers
    tickers = screening.carregar_universo()
    
    # Carrega estrategias ativas
    estrategias = screening.carregar_estrategias_ativas()
    
    if verbose:
        print("Estrategias: {}".format(', '.join([e['nome'] for e in estrategias])))
        print("Universo: {} tickers".format(len(tickers)))
        print("\nVerificando sinais...\n")
    
    # Lista de sinais detectados
    sinais = []
    
    # Para cada ticker
    for i, ticker in enumerate(tickers, 1):
        if verbose:
            print("[{:3d}/{}] {:12s}...".format(i, len(tickers), ticker), end=" ", flush=True)
        
        # Busca precos do ticker usando o database
        df_precos = db.buscar_precos(ticker, data_hoje, data_hoje)
        
        if df_precos.empty:
            if verbose:
                print("--")
            continue
        
        # Pega preco de fechamento de hoje
        preco_hoje = df_precos.iloc[0]['close']
        
        # Para cada estrategia, verifica se precisa buscar dados historicos
        # para calcular features tecnicas (RSI, max_52w, etc)
        sinais_ticker = []
        
        for est in estrategias:
            # Se estrategia requer features tecnicas, busca historico
            if est.get("requer_features_tecnicas", False):
                # Busca 1 ano de dados para calcular max_52w, RSI, etc
                data_inicio_historico = (pd.Timestamp(data_hoje) - pd.Timedelta(days=400)).strftime("%Y-%m-%d")
                df_historico = db.buscar_precos(ticker, data_inicio_historico, data_hoje)
                
                if len(df_historico) < 252:
                    continue
                
                # Prepara dados
                df_historico["data"] = pd.to_datetime(df_historico["data"])
                df_historico = df_historico.set_index("data")
                
                # Calcula features tecnicas
                df_features = screening.calcular_features_tecnicas(df_historico, ticker=ticker)
                
                # Pega features de hoje
                if data_hoje not in df_features.index:
                    continue
                
                row_hoje = df_features.loc[data_hoje]
            else:
                # Estrategia fundamentalista - nao implementado ainda
                continue
            
            # Pega funcao de sinal
            fn_sinal = est["fn_sinal"]
            p = est["parametros"]
            
            # Verifica se da sinal
            try:
                disparou = fn_sinal(row_hoje, p)
            except Exception as e:
                if verbose:
                    print("[DEBUG] Erro ao verificar sinal: {}".format(str(e)))
                disparou = False
            
            if disparou:
                # SINAL DETECTADO!
                
                # Calcula preco de entrada (abertura amanha + slippage)
                slippage = CFG["backtest"]["slippage_percent"]
                preco_entrada_estimado = preco_hoje * (1 + slippage)
                
                # Calcula alvo e stop
                alvo_preco = preco_entrada_estimado * (1 + p["alvo_pct"])
                stop_preco = preco_entrada_estimado * (1 + p["stop_loss_pct"])
                
                sinal = {
                    "ticker": ticker,
                    "estrategia": est["nome"],
                    "data_sinal": data_hoje,
                    "preco_fechamento": preco_hoje,
                    "preco_entrada_sugerido": preco_entrada_estimado,
                    "alvo_preco": alvo_preco,
                    "alvo_pct": p["alvo_pct"] * 100,
                    "stop_preco": stop_preco,
                    "stop_pct": p["stop_loss_pct"] * 100,
                    "holding_meses": p.get("holding_meses", 12),
                    "rsi": row_hoje.get("rsi", None),
                    "preco_vs_max_52w": row_hoje.get("preco_vs_max_52w", None),
                    "dy_12m": row_hoje.get("dy_12m", None),
                }
                
                sinais_ticker.append(sinal)
        
        if sinais_ticker:
            sinais.extend(sinais_ticker)
            if verbose:
                print("[OK] {} sinal(is)".format(len(sinais_ticker)))
        else:
            if verbose:
                print("--")
    
    conn.close()
    
    if verbose:
        print("\n" + "="*70)
        print("Total de sinais detectados: {}".format(len(sinais)))
        print("="*70 + "\n")
    
    return sinais


# ============================================================================
# ETAPA 3: ENVIAR E-MAIL
# ============================================================================

def gerar_email_html(sinais, data_atualizacao):
    """
    Gera HTML do e-mail com sinais de compra.
    
    Args:
        sinais: Lista de sinais detectados
        data_atualizacao: Data da ultima atualizacao
    
    Returns:
        str: HTML do e-mail
    """
    if len(sinais) == 0:
        # Sem sinais
        html = """
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .header {{ background-color: #f0f0f0; padding: 20px; border-radius: 5px; }}
                .footer {{ margin-top: 30px; font-size: 12px; color: #666; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h2>&#128269; Screening E4 - {}</h2>
                <p><strong>Status:</strong> Sem sinais de compra hoje.</p>
            </div>
            
            <p>Nenhum papel atendeu os criterios das estrategias ativas.</p>
            
            <p>Continue monitorando. Oportunidades aparecem em momentos de queda do mercado.</p>
            
            <div class="footer">
                <p>Sistema E4 - Screening automatico de oportunidades valor/dividendos</p>
                <p>Proximo screening: apos o fechamento de amanha</p>
            </div>
        </body>
        </html>
        """.format(data_atualizacao)
        return html
    
    # Com sinais
    linhas_sinais = []
    
    for s in sinais:
        queda_pct = (1 - s['preco_vs_max_52w']) * 100 if s['preco_vs_max_52w'] else 0
        dy_pct = s['dy_12m'] * 100 if s['dy_12m'] else 0
        
        linha = """
        <tr>
            <td><strong>{}</strong></td>
            <td>{}</td>
            <td>R$ {:.2f}</td>
            <td>R$ {:.2f}</td>
            <td style="color: green;">R$ {:.2f} (+{:.0f}%)</td>
            <td style="color: red;">R$ {:.2f} ({:.0f}%)</td>
            <td>{} meses</td>
            <td>{:.1f}</td>
            <td>{:.1f}%</td>
            <td>{:.1f}%</td>
        </tr>
        """.format(
            s['ticker'],
            s['estrategia'],
            s['preco_fechamento'],
            s['preco_entrada_sugerido'],
            s['alvo_preco'],
            s['alvo_pct'],
            s['stop_preco'],
            s['stop_pct'],
            s['holding_meses'],
            s['rsi'] if s['rsi'] else 0,
            queda_pct,
            dy_pct
        )
        linhas_sinais.append(linha)
    
    html = """
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; }}
            .header {{ background-color: #4CAF50; color: white; padding: 20px; border-radius: 5px; }}
            table {{ border-collapse: collapse; width: 100%; margin-top: 20px; }}
            th {{ background-color: #f0f0f0; padding: 10px; text-align: left; border: 1px solid #ddd; }}
            td {{ padding: 10px; border: 1px solid #ddd; }}
            .instrucoes {{ background-color: #fff3cd; padding: 15px; border-radius: 5px; margin-top: 20px; }}
            .footer {{ margin-top: 30px; font-size: 12px; color: #666; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h2>&#127919; {} SINAL(IS) DE COMPRA DETECTADO(S)!</h2>
            <p>Data: {}</p>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>Ticker</th>
                    <th>Estrategia</th>
                    <th>Preco Fech.</th>
                    <th>Entrada Sug.</th>
                    <th>Alvo</th>
                    <th>Stop</th>
                    <th>Holding</th>
                    <th>RSI</th>
                    <th>Queda 52w</th>
                    <th>DY</th>
                </tr>
            </thead>
            <tbody>
                {}
            </tbody>
        </table>
        
        <div class="instrucoes">
            <h3>&#128203; Instrucoes de Execucao:</h3>
            <ol>
                <li><strong>Timing:</strong> Executar ordens LIMIT na abertura do proximo pregao (9h30)</li>
                <li><strong>Preco:</strong> Usar "Preco Entrada Sugerido" como limite (ja inclui slippage estimado)</li>
                <li><strong>Validade:</strong> Ordem valida por 1 dia (DAY order)</li>
                <li><strong>Stop Loss:</strong> Configurar stop loss automatico no preco indicado</li>
                <li><strong>Alvo:</strong> Configurar alerta de preco no valor do alvo</li>
            </ol>
            
            <p><strong>&#9888; Importante:</strong> Confirme liquidez e spread antes de executar. Em caso de volatilidade extrema, considere aguardar estabilizacao.</p>
        </div>
        
        <div class="footer">
            <p>Sistema E4 - Screening automatico de oportunidades valor/dividendos</p>
            <p>Baseado em estrategias de mean reversion com criterios fundamentalistas</p>
            <p>Proximo screening: apos o fechamento de amanha</p>
        </div>
    </body>
    </html>
    """.format(len(sinais), data_atualizacao, ''.join(linhas_sinais))
    
    return html


def enviar_relatorio(sinais, data_atualizacao, dry_run=False):
    """
    Envia e-mail com resumo do screening.
    
    Args:
        sinais: Lista de sinais detectados
        data_atualizacao: Data da atualizacao
        dry_run: Se True, apenas imprime mas nao envia
    
    Returns:
        bool: True se enviou com sucesso
    """
    print("\n" + "="*70)
    print("ETAPA 3: Enviando relatorio")
    print("="*70)
    
    # Gera HTML
    html = gerar_email_html(sinais, data_atualizacao)
    
    # Assunto
    if len(sinais) > 0:
        assunto = "[ALERTA] E4 Screening - {} SINAL(IS) DE COMPRA - {}".format(
            len(sinais), data_atualizacao
        )
    else:
        assunto = "[INFO] E4 Screening - Sem sinais - {}".format(data_atualizacao)
    
    if dry_run:
        print("\n[DRY RUN] E-mail NAO enviado. Conteudo:")
        print("Assunto: {}".format(assunto))
        print("Sinais: {}".format(len(sinais)))
        if len(sinais) > 0:
            for s in sinais:
                print("  - {} ({}): R$ {:.2f}".format(
                    s['ticker'],
                    s['estrategia'],
                    s['preco_entrada_sugerido']
                ))
        return True
    
    # Envia e-mail
    try:
        utils.enviar_email_gmail_com_app_password(
            assunto=assunto,
            corpo_html=html
        )
        print("[OK] E-mail enviado com sucesso!")
        print("  Destinatario: {}".format(EMAIL_CONFIG['destinatario']))
        print("  Sinais: {}".format(len(sinais)))
        return True
    
    except Exception as e:
        print("[X] Erro ao enviar e-mail: {}".format(str(e)))
        return False


# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(description="Screening diario E4")
    parser.add_argument("--dry-run", action="store_true", 
                       help="Teste sem enviar e-mail")
    parser.add_argument("--skip-update", action="store_true",
                       help="Pula atualizacao do banco (para testes)")
    args = parser.parse_args()
    
    print("="*70)
    print("E4 SCREENING DIARIO")
    print("="*70)
    print("Data/Hora: {}".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    
    if args.dry_run:
        print("Modo: DRY RUN (teste)")
    
    print("="*70)
    
    # ETAPA 1: Atualizar banco
    if not args.skip_update:
        sucesso, msg = atualizar_banco_dados(verbose=True)
        
        if not sucesso:
            print("\n[X] ERRO: Falha ao atualizar banco: {}".format(msg))
            print("Abortando screening.")
            sys.exit(1)
    else:
        print("\n[!] Pulando atualizacao do banco (--skip-update)")
    
    # ETAPA 2: Detectar sinais
    try:
        sinais = detectar_sinais_hoje(verbose=True)
    except Exception as e:
        print("\n[X] ERRO ao detectar sinais: {}".format(str(e)))
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # ETAPA 3: Enviar e-mail
    data_hoje = datetime.now().strftime("%Y-%m-%d")
    
    sucesso = enviar_relatorio(sinais, data_hoje, dry_run=args.dry_run)
    
    if sucesso:
        print("\n" + "="*70)
        print("[OK] SCREENING CONCLUIDO COM SUCESSO!")
        print("="*70)
        print("Sinais detectados: {}".format(len(sinais)))
        print("Proxima execucao: apos fechamento de amanha")
    else:
        print("\n" + "="*70)
        print("[!] SCREENING CONCLUIDO COM AVISOS")
        print("="*70)
        print("Verifique configuracao de e-mail em EMAIL_CONFIG")
    
    print()


if __name__ == "__main__":
    main()