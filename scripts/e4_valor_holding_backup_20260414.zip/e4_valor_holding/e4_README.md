# E4 - Sistema de Valor/Dividendos com Holding Otimizado

Sistema de screening e backtest para estratégias Valor/Dividendos com otimização de holding period.

## 📁 Estrutura

```
e4_valor_holding/
├── e4_config.json              # Configuração central
├── e4_database.py              # Gerenciador de banco de dados
├── e4_scraping_fundamentus.py # Coleta dados fundamentalistas
├── e4_scraping_precos.py       # Coleta preços históricos
├── e4_screening.py             # Motor de screening/backtest
├── e4_universo_b3.txt          # Lista de tickers
├── estrategias/                # Estratégias testáveis
│   ├── valor_tempo_fixo_12m.py
│   ├── valor_alvo_20pct.py
│   └── valor_fundamentalista.py
└── data/                       # Bancos de dados
    ├── fundamentalista.db
    └── precos.db
```

## 🚀 Quick Start

### 1. Coletar Dados

```bash
# Coletar dados fundamentalistas (Fundamentus)
python e4_scraping_fundamentus.py --todos

# Coletar preços históricos (yfinance)
python e4_scraping_precos.py --todos
```

### 2. Rodar Backtest

```bash
# Backtest completo (todas estratégias ativas)
python e4_screening.py

# Testar estratégia específica
python e4_screening.py --estrategia valor_tempo_fixo_12m

# Debug em papel único
python e4_screening.py --ticker PETR4.SA
```

## 📊 Estratégias Disponíveis

### 1. **valor_tempo_fixo_12m** (Holding Fixo)
- Compra: P/L < 8, DY > 6%, ROE > 15%
- Venda: Após 12 meses
- Hipótese: Reversão à média em ~1 ano

### 2. **valor_alvo_20pct** (Alvo de Ganho)
- Compra: Mesmos critérios de valor
- Venda: Ao atingir +20% OU após 24 meses
- Hipótese: Maioria reverte rápido (~6-12m)

### 3. **valor_fundamentalista** (Deterioração)
- Compra: Mesmos critérios de valor
- Venda: Quando P/L > 12 OU ROE < 10%
- Hipótese: Sair quando retorna à média ou deteriora

## 🎯 Próximos Passos

1. Coletar dados históricos (2015-2024)
2. Rodar backtest comparativo
3. Identificar estratégia ótima
4. Implementar sistema de acompanhamento real-time
