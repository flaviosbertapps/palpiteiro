"""
e4_scraping_fundamentus.py
===========================
Scraper de dados fundamentalistas do site Fundamentus.

Coleta:
  - P/L, P/VP, DY, ROE, ROIC, Margem Líquida
  - Dívida/Patrimônio, Liquidez Corrente
  - Volume médio de negociação

Armazena em: data/fundamentalista.db
"""

import requests
import json
import time
from datetime import datetime, date
from typing import Dict, Optional
from bs4 import BeautifulSoup
import re

import e4_database as db

# Carregar configuração
with open("e4_config.json") as f:
    CFG = json.load(f)


# ===========================================================================
# Scraping
# ===========================================================================

def scrape_ticker_fundamentus(ticker_base: str) -> Optional[Dict]:
    """
    Faz scraping de um ticker no Fundamentus.
    
    Args:
        ticker_base: Ticker SEM sufixo .SA (ex: "PETR4")
    
    Returns:
        Dict com dados fundamentalistas ou None se falhou
    """
    url = f"{CFG['scraping']['fundamentus_url']}?papel={ticker_base}"
    headers = {"User-Agent": CFG['scraping']['user_agent']}
    
    try:
        response = requests.get(
            url, 
            headers=headers,
            timeout=CFG['scraping']['timeout_segundos']
        )
        
        if response.status_code != 200:
            print(f"   ✗ {ticker_base}: HTTP {response.status_code}")
            return None
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Função auxiliar para extrair valor
        def extrair_valor(soup, label_texto):
            try:
                # Procura pela label
                label = soup.find('span', string=re.compile(label_texto))
                if not label:
                    return None
                
                # Pega o valor na mesma linha
                tr = label.find_parent('tr')
                if not tr:
                    return None
                
                valor_span = tr.find_all('span')[-1]
                valor_texto = valor_span.text.strip()
                
                # Limpa e converte
                valor_texto = valor_texto.replace('.', '').replace(',', '.')
                valor_texto = valor_texto.replace('%', '')
                valor_texto = valor_texto.replace('R$', '').strip()
                
                # Remove sufixos de milhares/milhões
                if 'M' in valor_texto:
                    valor_texto = valor_texto.replace('M', '')
                    return float(valor_texto) * 1_000_000
                elif 'B' in valor_texto or 'Bi' in valor_texto:
                    valor_texto = valor_texto.replace('B', '').replace('Bi', '')
                    return float(valor_texto) * 1_000_000_000
                
                return float(valor_texto) if valor_texto else None
            
            except (ValueError, AttributeError):
                return None
        
        # Extrai cada métrica
        dados = {
            "ticker": f"{ticker_base}.SA",
            "data": str(date.today()),
            
            # Valuation
            "p_l": extrair_valor(soup, r"P/L"),
            "p_vp": extrair_valor(soup, r"P/VP"),
            "p_ebit": extrair_valor(soup, r"P/EBIT"),
            "psr": extrair_valor(soup, r"PSR"),
            "p_ativo": extrair_valor(soup, r"P/Ativo"),
            "p_cap_giro": extrair_valor(soup, r"P/Cap\.Giro"),
            "p_ativ_circ_liq": extrair_valor(soup, r"P/Ativ Circ Liq"),
            
            # Rentabilidade
            "dy": extrair_valor(soup, r"Div\. Yield"),
            "roe": extrair_valor(soup, r"ROE"),
            "roic": extrair_valor(soup, r"ROIC"),
            "roa": extrair_valor(soup, r"ROA"),
            "liq_corrente": extrair_valor(soup, r"Liq\. Corrente"),
            
            # Endividamento
            "div_brut_patrim": extrair_valor(soup, r"Dív\.Brut/Patrim"),
            "divida_ebit": extrair_valor(soup, r"Dív\.Líquida/EBIT"),
            
            # Crescimento
            "cagr_receita_5a": extrair_valor(soup, r"CAGR Receitas 5 anos"),
            "cagr_lucro_5a": extrair_valor(soup, r"CAGR Lucros 5 anos"),
            
            # Margens
            "margem_bruta": extrair_valor(soup, r"Marg\. Bruta"),
            "margem_ebit": extrair_valor(soup, r"Marg\. EBIT"),
            "margem_liquida": extrair_valor(soup, r"Marg\. Líquida"),
            
            # Liquidez de mercado
            "vol_med_2m": extrair_valor(soup, r"Vol \$ méd \(2m\)"),
        }
        
        # Converte percentuais para decimais
        for key in ["dy", "roe", "roic", "roa", "margem_bruta", "margem_ebit", "margem_liquida", 
                    "cagr_receita_5a", "cagr_lucro_5a"]:
            if dados[key] is not None:
                dados[key] = dados[key] / 100
        
        return dados
    
    except requests.RequestException as e:
        print(f"   ✗ {ticker_base}: {e}")
        return None


def scrape_universo(tickers: list) -> int:
    """
    Faz scraping de uma lista de tickers e salva no banco.
    
    Args:
        tickers: Lista de tickers COM sufixo .SA
    
    Returns:
        Número de tickers processados com sucesso
    """
    database = db.get_db()
    sucesso = 0
    
    print(f"\n{'='*70}")
    print(f"SCRAPING FUNDAMENTUS - {len(tickers)} tickers")
    print(f"{'='*70}\n")
    
    for i, ticker in enumerate(tickers, 1):
        # Remove sufixo .SA para consulta no Fundamentus
        ticker_base = ticker.replace(".SA", "")
        
        print(f"[{i:3d}/{len(tickers)}] {ticker_base}...", end=" ", flush=True)
        
        dados = scrape_ticker_fundamentus(ticker_base)
        
        if dados:
            # Salva no banco
            database.inserir_fundamentalista([dados])
            print(f"✓ (P/L={dados.get('p_l', 'N/A')}, DY={dados.get('dy', 'N/A')})")
            sucesso += 1
        else:
            print("✗")
        
        # Delay entre requests
        time.sleep(CFG['scraping']['delay_segundos'])
    
    print(f"\n{'='*70}")
    print(f"✓ Concluído: {sucesso}/{len(tickers)} tickers processados")
    print(f"{'='*70}\n")
    
    return sucesso


# ===========================================================================
# CLI
# ===========================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Scraper de dados fundamentalistas")
    parser.add_argument("--ticker", help="Ticker único para testar (ex: PETR4)")
    parser.add_argument("--universo", help="Arquivo com lista de tickers (1 por linha)")
    parser.add_argument("--todos", action="store_true", help="Scrape todos os tickers do universo padrão")
    
    args = parser.parse_args()
    
    if args.ticker:
        # Teste com ticker único
        print(f"\nTestando scraping de {args.ticker}...\n")
        dados = scrape_ticker_fundamentus(args.ticker)
        
        if dados:
            print("\nDados coletados:")
            for key, value in dados.items():
                if value is not None:
                    print(f"  {key:20s}: {value}")
        else:
            print("Falha ao coletar dados.")
    
    elif args.universo or args.todos:
        # Scrape de lista
        if args.todos:
            arquivo = CFG['universo']['arquivo']
        else:
            arquivo = args.universo
        
        try:
            with open(arquivo) as f:
                tickers = [line.strip() for line in f if line.strip()]
            
            scrape_universo(tickers)
        
        except FileNotFoundError:
            print(f"Erro: Arquivo '{arquivo}' não encontrado.")
            print("Crie o arquivo com um ticker por linha (ex: PETR4.SA)")
    
    else:
        parser.print_help()
