"""
e4_relatorio_trades.py
======================
Gera relatório detalhado dos trades por papel, ano, motivo de saída, etc.

USO:
    python e4_relatorio_trades.py
    python e4_relatorio_trades.py --estrategia valor_tecnico_dividendos
    python e4_relatorio_trades.py --exportar trades_detalhados.xlsx
"""

import pandas as pd
import json
import argparse

import e4_screening as screening

with open("e4_config.json") as f:
    CFG = json.load(f)


def gerar_relatorio_detalhado(nome_estrategia: str = None, exportar: str = None):
    """Gera relatório detalhado de trades"""
    
    # Carrega estratégias
    if nome_estrategia:
        estrategias = [screening.carregar_estrategia(nome_estrategia)]
    else:
        estrategias = screening.carregar_estrategias_ativas()
    
    # Carrega universo
    arquivo_universo = CFG["universo"]["arquivo"]
    with open(arquivo_universo) as f:
        tickers = [line.strip() for line in f if line.strip()]
    
    print(f"\n{'='*70}")
    print(f"RELATÓRIO DETALHADO DE TRADES")
    print(f"{'='*70}")
    print(f"Estratégias: {[e['nome'] for e in estrategias]}")
    print(f"Tickers: {len(tickers)}")
    print(f"Período: {CFG['backtest']['data_inicio']} até {CFG['backtest']['data_fim']}")
    print(f"{'='*70}\n")
    
    # Executa backtest
    resultados = screening.backtest_completo(estrategias, tickers)
    
    # Processa cada estratégia
    dfs_exportar = {}
    
    for nome_est, trades in resultados.items():
        if not trades:
            print(f"\n{nome_est}: Sem trades")
            continue
        
        df = pd.DataFrame(trades)
        dfs_exportar[nome_est] = df
        
        # Adiciona colunas derivadas
        df['data_entrada'] = pd.to_datetime(df['data_entrada'])
        df['data_saida'] = pd.to_datetime(df['data_saida'])
        df['ano_entrada'] = df['data_entrada'].dt.year
        df['mes_entrada'] = df['data_entrada'].dt.month
        df['ganhou'] = df['retorno_%'] > 0
        
        print(f"\n{'='*70}")
        print(f"ESTRATÉGIA: {nome_est}")
        print(f"{'='*70}\n")
        
        # 1. Resumo Geral
        print("1. RESUMO GERAL")
        print("-" * 70)
        print(f"Total de trades: {len(df)}")
        print(f"Taxa de acerto: {df['ganhou'].sum() / len(df) * 100:.1f}%")
        print(f"Retorno médio: {df['retorno_%'].mean():.2f}%")
        print(f"Retorno mediano: {df['retorno_%'].median():.2f}%")
        print(f"Maior ganho: {df['retorno_%'].max():.2f}%")
        print(f"Maior perda: {df['retorno_%'].min():.2f}%")
        print(f"Holding médio: {df['dias'].mean():.0f} dias")
        
        # 2. Por Papel
        print(f"\n2. DESEMPENHO POR PAPEL")
        print("-" * 70)
        
        por_papel = df.groupby('ticker').agg({
            'retorno_%': ['count', 'mean', lambda x: (x > 0).sum() / len(x) * 100],
            'dias': 'mean'
        }).round(2)
        
        por_papel.columns = ['Trades', 'Ret Médio %', 'Taxa %', 'Hold (d)']
        por_papel = por_papel.sort_values('Ret Médio %', ascending=False)
        
        print(por_papel.to_string())
        
        # 3. Por Ano
        print(f"\n3. DESEMPENHO POR ANO")
        print("-" * 70)
        
        por_ano = df.groupby('ano_entrada').agg({
            'retorno_%': ['count', 'mean', lambda x: (x > 0).sum() / len(x) * 100]
        }).round(2)
        
        por_ano.columns = ['Trades', 'Ret Médio %', 'Taxa %']
        
        print(por_ano.to_string())
        
        # 4. Por Motivo de Saída
        print(f"\n4. MOTIVO DE SAÍDA")
        print("-" * 70)
        
        por_motivo = df.groupby('motivo_saida').agg({
            'retorno_%': ['count', 'mean', lambda x: (x > 0).sum() / len(x) * 100]
        }).round(2)
        
        por_motivo.columns = ['Trades', 'Ret Médio %', 'Taxa %']
        por_motivo = por_motivo.sort_values('Trades', ascending=False)
        
        print(por_motivo.to_string())
        
        # 5. Melhores e Piores Trades
        print(f"\n5. TOP 10 MELHORES TRADES")
        print("-" * 70)
        
        melhores = df.nlargest(10, 'retorno_%')[
            ['ticker', 'data_entrada', 'data_saida', 'retorno_%', 'dias', 'motivo_saida']
        ]
        print(melhores.to_string(index=False))
        
        print(f"\n6. TOP 10 PIORES TRADES")
        print("-" * 70)
        
        piores = df.nsmallest(10, 'retorno_%')[
            ['ticker', 'data_entrada', 'data_saida', 'retorno_%', 'dias', 'motivo_saida']
        ]
        print(piores.to_string(index=False))
        
        # 7. Distribuição de Retornos
        print(f"\n7. DISTRIBUIÇÃO DE RETORNOS")
        print("-" * 70)
        
        bins = [-100, -20, -10, 0, 10, 20, 30, 100]
        labels = ['< -20%', '-20 a -10%', '-10 a 0%', '0 a 10%', '10 a 20%', '20 a 30%', '> 30%']
        
        df['faixa'] = pd.cut(df['retorno_%'], bins=bins, labels=labels)
        dist = df['faixa'].value_counts().sort_index()
        
        for faixa, count in dist.items():
            pct = count / len(df) * 100
            print(f"{faixa:12s}: {count:3d} trades ({pct:5.1f}%)")
        
        # 8. Análise Temporal
        print(f"\n8. RETORNO POR MÊS DO ANO (entrada)")
        print("-" * 70)
        
        meses_com_trades = df['mes_entrada'].unique()
        por_mes = df.groupby('mes_entrada')['retorno_%'].agg(['count', 'mean']).round(2)
        por_mes.columns = ['Trades', 'Ret Médio %']
        
        # Cria índice completo 1-12
        meses_nomes = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 
                       'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
        
        # Só mostra meses que têm trades
        for mes in sorted(meses_com_trades):
            if mes in por_mes.index:
                trades = por_mes.loc[mes, 'Trades']
                ret = por_mes.loc[mes, 'Ret Médio %']
                print(f"{meses_nomes[mes-1]:3s}: {trades:3.0f} trades, ret médio {ret:6.2f}%")
        
        # 9. Estatísticas dos Winners vs Losers
        print(f"\n9. WINNERS vs LOSERS")
        print("-" * 70)
        
        winners = df[df['ganhou']]
        losers = df[~df['ganhou']]
        
        print(f"\nWINNERS ({len(winners)} trades, {len(winners)/len(df)*100:.1f}%):")
        print(f"  Retorno médio: {winners['retorno_%'].mean():.2f}%")
        print(f"  Holding médio: {winners['dias'].mean():.0f} dias")
        print(f"  Maior ganho: {winners['retorno_%'].max():.2f}%")
        
        if len(losers) > 0:
            print(f"\nLOSERS ({len(losers)} trades, {len(losers)/len(df)*100:.1f}%):")
            print(f"  Perda média: {losers['retorno_%'].mean():.2f}%")
            print(f"  Holding médio: {losers['dias'].mean():.0f} dias")
            print(f"  Maior perda: {losers['retorno_%'].min():.2f}%")
            
            print(f"\nRISK/REWARD:")
            avg_win = winners['retorno_%'].mean()
            avg_loss = abs(losers['retorno_%'].mean())
            print(f"  Ganho médio / Perda média: {avg_win / avg_loss:.2f}x")
        else:
            print(f"\nLOSERS: 0 trades (100% de acerto!)")
    
    # Exportar para Excel
    if exportar and dfs_exportar:
        with pd.ExcelWriter(exportar) as writer:
            for nome_est, df in dfs_exportar.items():
                # Remove colunas derivadas que adicionamos
                df_export = df.drop(columns=['ano_entrada', 'mes_entrada', 'ganhou', 'faixa'], errors='ignore')
                df_export.to_excel(writer, sheet_name=nome_est[:31], index=False)
        
        print(f"\n✓ Exportado para {exportar}")
    
    return dfs_exportar


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Relatório detalhado de trades")
    parser.add_argument("--estrategia", help="Nome da estratégia")
    parser.add_argument("--exportar", help="Exportar para Excel")
    
    args = parser.parse_args()
    
    gerar_relatorio_detalhado(args.estrategia, args.exportar)