"""
e4_scraping_statusinvest.py
============================
Scraper de dados fundamentalistas HISTÓRICOS do StatusInvest.

IMPORTANTE: 
  - Este scraper é para uso educacional/pessoal
  - Respeite o robots.txt e rate limits
  - StatusInvest pode mudar endpoints a qualquer momento

Dados coletados:
  - P/L, P/VP, DY, ROE, ROIC históricos (5 anos, trimestral)
  - Margens, liquidez, endividamento
"""

import requests
import json
import time
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Dict, Optional

import e4_database as db

with open("e4_config.json") as f:
    CFG = json.load(f)


# ===========================================================================
# Config
# ===========================================================================

CONFIG = {
    "base_url": "https://statusinvest.com.br",
    "headers": {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json",
        "Accept-Language": "pt-BR,pt;q=0.9",
        "Referer": "https://statusinvest.com.br/acoes/",
    },
    "delay": 3,  # Segundos entre requests (ético)
    "timeout": 15,
}


# ===========================================================================
# Scraping
# ===========================================================================

def buscar_indicadores_historicos(ticker_base: str) -> Optional[pd.DataFrame]:
    """
    Busca histórico de indicadores do StatusInvest.
    
    Endpoint: /acao/indicatorhistoricallist
    
    Args:
        ticker_base: Ticker SEM .SA (ex: "PETR4")
    
    Returns:
        DataFrame com snapshots trimestrais ou None
    """
    url = f"{CONFIG['base_url']}/acao/indicatorhistoricallist"
    
    params = {
        "ticker": ticker_base,
        "time": 5,  # Anos de histórico
    }
    
    try:
        resp = requests.get(
            url,
            params=params,
            headers=CONFIG["headers"],
            timeout=CONFIG["timeout"]
        )
        
        if resp.status_code != 200:
            return None
        
        data = resp.json()
        
        if not data:
            return None
        
        # Mapeamento de campos
        campos = {
            "p_L": "p_l",
            "p_VP": "p_vp",
            "dividend_Yield": "dy",
            "roe": "roe",
            "roic": "roic",
            "p_Ebit": "p_ebit",
            "p_Ativo": "p_ativo",
            "margemBruta": "margem_bruta",
            "margemEbit": "margem_ebit",
            "margemLiquida": "margem_liquida",
            "liquidezCorrente": "liq_corrente",
            "divBrutaPatrimonioLiquido": "div_brut_patrim",
        }
        
        # Encontra primeiro indicador disponível para pegar número de períodos
        primeiro = None
        for key in campos.keys():
            if key in data and data[key]:
                primeiro = key
                break
        
        if not primeiro or not data[primeiro]:
            return None
        
        # Constrói registros
        registros = []
        n_periodos = len(data[primeiro])
        
        for i in range(n_periodos):
            # Rank 1 = mais recente
            rank = data[primeiro][i].get("rank", i + 1)
            
            # Infere data (aproximação: rank 1 = hoje - 0 meses, rank 2 = hoje - 3 meses, etc.)
            meses_atras = (rank - 1) * 3
            data_inferida = (datetime.now() - timedelta(days=meses_atras*30)).strftime("%Y-%m-%d")
            
            registro = {
                "ticker": f"{ticker_base}.SA",
                "data": data_inferida,
            }
            
            # Extrai cada campo
            for key_status, key_db in campos.items():
                if key_status in data and len(data[key_status]) > i:
                    valor = data[key_status][i].get("value")
                    
                    # Converte % para decimal
                    if key_db in ["dy", "roe", "roic", "margem_bruta", "margem_ebit", "margem_liquida"]:
                        if valor is not None:
                            valor = valor / 100
                    
                    registro[key_db] = valor
            
            registros.append(registro)
        
        return pd.DataFrame(registros) if registros else None
    
    except Exception as e:
        print(f"   ✗ Erro: {e}")
        return None


def scrape_universo(tickers: List[str]) -> int:
    """Scrape lista de tickers"""
    database = db.get_db()
    sucesso = 0
    
    print(f"\n{'='*70}")
    print(f"SCRAPING STATUSINVEST - {len(tickers)} tickers")
    print(f"Histórico: 5 anos (trimestral)")
    print(f"{'='*70}\n")
    
    for i, ticker in enumerate(tickers, 1):
        ticker_base = ticker.replace(".SA", "")
        
        print(f"[{i:3d}/{len(tickers)}] {ticker_base}...", end=" ", flush=True)
        
        df = buscar_indicadores_historicos(ticker_base)
        
        if df is not None and not df.empty:
            # Salva no banco
            dados = df.to_dict('records')
            database.inserir_fundamentalista(dados)
            
            print(f"✓ ({len(df)} snapshots)")
            sucesso += 1
        else:
            print("✗")
        
        time.sleep(CONFIG["delay"])
    
    print(f"\n{'='*70}")
    print(f"✓ {sucesso}/{len(tickers)} tickers processados")
    print(f"{'='*70}\n")
    
    return sucesso


# ===========================================================================
# CLI
# ===========================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Scraper StatusInvest")
    parser.add_argument("--ticker", help="Ticker único (ex: PETR4)")
    parser.add_argument("--universo", help="Arquivo com tickers")
    parser.add_argument("--todos", action="store_true", help="Universo padrão")
    
    args = parser.parse_args()
    
    if args.ticker:
        print(f"\nTestando {args.ticker}...\n")
        df = buscar_indicadores_historicos(args.ticker)
        
        if df is not None:
            print("Dados coletados:")
            print(df[["data", "p_l", "dy", "roe"]].to_string())
            print(f"\nTotal: {len(df)} snapshots")
            
            # Salva no banco
            database = db.get_db()
            database.inserir_fundamentalista(df.to_dict('records'))
            print("\n✓ Salvo no banco de dados")
        else:
            print("✗ Falha")
    
    elif args.universo or args.todos:
        arquivo = CFG['universo']['arquivo'] if args.todos else args.universo
        
        try:
            with open(arquivo) as f:
                tickers = [line.strip() for line in f if line.strip()]
            
            scrape_universo(tickers)
        
        except FileNotFoundError:
            print(f"Erro: {arquivo} não encontrado")
    
    else:
        parser.print_help()