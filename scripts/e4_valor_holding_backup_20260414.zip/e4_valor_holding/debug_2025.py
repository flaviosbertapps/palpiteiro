"""
Debug 2025: Backtest detalhado
================================
Roda screening APENAS em 2025 com logs verbosos
"""

import json
import sys

# Salva config atual
with open("e4_config.json") as f:
    config_original = json.load(f)

# Cria config temporária para 2025
config_2025 = config_original.copy()
config_2025["backtest"]["data_inicio"] = "2025-01-01"
config_2025["backtest"]["data_fim"] = "2026-03-19"

# Salva temporariamente
with open("e4_config_temp.json", "w") as f:
    json.dump(config_2025, f, indent=2)

print("="*70)
print("DEBUG BACKTEST 2025")
print("="*70)
print("Período: 2025-01-01 até 2026-03-19 (hoje)")
print("="*70)

# Modifica temporariamente para usar config temp
import e4_screening as screening

# Recarrega com config temp
screening.CFG = config_2025

# Carrega estratégia
estrategia = screening.carregar_estrategia("valor_tecnico_dividendos")

print(f"\nEstratégia: {estrategia['nome']}")
print(f"Parâmetros:")
for k, v in estrategia['parametros'].items():
    print(f"  {k}: {v}")

# Testa alguns tickers manualmente
tickers_teste = [
    "PETR4.SA", "VALE3.SA", "ITUB4.SA", "BBDC4.SA", 
    "ABEV3.SA", "CSNA3.SA", "LREN3.SA", "MGLU3.SA"
]

print(f"\n{'='*70}")
print(f"TESTANDO {len(tickers_teste)} TICKERS EM 2025")
print(f"{'='*70}\n")

resultados = {}

for ticker in tickers_teste:
    print(f"{ticker}:")
    
    try:
        # Roda backtest neste ticker
        trades = screening.backtest_papel(
            ticker, 
            estrategia, 
            "2025-01-01", 
            "2026-03-19"
        )
        
        if trades:
            print(f"  ✓ {len(trades)} trade(s)")
            for t in trades:
                print(f"    Entrada: {t['data_entrada']}, Saída: {t['data_saida']}")
                print(f"    Retorno: {t['retorno_%']:.2f}%, Motivo: {t['motivo_saida']}")
            resultados[ticker] = trades
        else:
            print(f"  — Sem trades")
    
    except Exception as e:
        print(f"  ✗ Erro: {e}")
        import traceback
        traceback.print_exc()

print(f"\n{'='*70}")
print(f"RESUMO 2025")
print(f"{'='*70}")

total_trades = sum(len(t) for t in resultados.values())
print(f"Total de trades: {total_trades}")

if total_trades > 0:
    print(f"\nTrades por ticker:")
    for ticker, trades in resultados.items():
        print(f"  {ticker}: {len(trades)} trades")
else:
    print("\n❌ NENHUM TRADE EM 2025!")
    print("\nPOSSÍVEIS CAUSAS:")
    print("1. Mercado não caiu em 2025 (ano de alta)")
    print("2. Critérios muito restritos")
    print("3. RSI não ficou < 28 em nenhum papel")
    print("\nVamos verificar se houve QUEDAS em 2025:")
    print("(próximo script: analisar_quedas_2025.py)")

# Remove arquivo temp
import os
os.remove("e4_config_temp.json")