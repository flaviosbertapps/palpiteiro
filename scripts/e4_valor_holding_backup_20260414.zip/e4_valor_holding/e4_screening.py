# -*- coding: utf-8 -*-
"""
e4_screening.py
===============
Motor de screening e backtest para estrategias Valor/Dividendos.

Otimizacao: Loop por PAPEL (nao por data) para minimizar consultas ao banco.

CORRECAO CRITICA APLICADA (2026-03-20):
  - Corrigido bug de trades duplicados no mesmo papel
  - Motor agora rastreia ultima_data_saida e pula datas durante trade ativo
  - TODOS resultados anteriores foram invalidados e devem ser re-testados
  - Ver BUG_TRADES_DUPLICADOS.md para detalhes

Comandos:
    python e4_screening.py                    # Backtest completo
    python e4_screening.py --estrategia X     # Apenas estrategia X
    python e4_screening.py --ticker PETR4.SA  # Debug em papel unico
"""

import sys
import os

# SOLUCAO ROBUSTA PARA WINDOWS
if sys.platform == 'win32':
    try:
        import io
        if sys.stdout.encoding != 'cp1252':
            sys.stdout = io.TextIOWrapper(
                sys.stdout.buffer, 
                encoding='cp1252', 
                errors='replace',
                line_buffering=True
            )
        if sys.stderr.encoding != 'cp1252':
            sys.stderr = io.TextIOWrapper(
                sys.stderr.buffer, 
                encoding='cp1252', 
                errors='replace',
                line_buffering=True
            )
    except (AttributeError, ValueError):
        pass

import json
import argparse
import importlib.util
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import pandas as pd
import numpy as np

import e4_database as db

# Carregar configuracao
with open("e4_config.json", encoding='utf-8') as f:
    CFG = json.load(f)


# ===========================================================================
# Carregamento de estratégias
# ===========================================================================

def carregar_estrategia(nome: str) -> dict:
    """
    Importa dinamicamente uma estratégia de estrategias/<nome>.py
    ou do diretório raiz <nome>.py
    """
    # Tenta estrategias/ primeiro
    pasta_est = Path("estrategias")
    caminho = pasta_est / f"{nome}.py"
    
    # Se não existe, tenta raiz
    if not caminho.exists():
        caminho = Path(f"{nome}.py")
    
    if not caminho.exists():
        raise FileNotFoundError(f"Estratégia '{nome}' não encontrada em estrategias/ ou raiz")
    
    spec = importlib.util.spec_from_file_location(nome, caminho)
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    
    if not hasattr(modulo, "ESTRATEGIA"):
        raise AttributeError(f"{caminho} não exporta ESTRATEGIA")
    
    return modulo.ESTRATEGIA


def carregar_estrategias_ativas() -> List[dict]:
    """Carrega todas as estratégias listadas em e4_config.json"""
    nomes = CFG["estrategias_ativas"]
    
    estrategias = []
    for nome in nomes:
        try:
            est = carregar_estrategia(nome)
            estrategias.append(est)
        except Exception as e:
            print(f"[AVISO] Não foi possível carregar '{nome}': {e}")
    
    return estrategias


# ===========================================================================
# Motor de backtest (otimizado por papel)
# ===========================================================================

def calcular_features_tecnicas(df_precos: pd.DataFrame, ticker: str = None) -> pd.DataFrame:
    """
    Calcula features técnicas a partir de DataFrame de preços.
    
    Args:
        df_precos: DataFrame com colunas [open, high, low, close, volume]
                   e index como data
        ticker: Ticker (opcional, para buscar dividendos)
    
    Returns:
        DataFrame com features adicionadas
    """
    df = df_precos.copy()
    
    # RSI (14 períodos)
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    df['rsi'] = 100 - (100 / (1 + rs))
    
    # Máxima de 52 semanas (252 dias úteis)
    df['max_52w'] = df['high'].rolling(window=252, min_periods=1).max()
    df['preco_vs_max_52w'] = df['close'] / df['max_52w']
    
    # Volume relativo (vs média 20 dias)
    df['vol_medio_20d'] = df['volume'].rolling(window=20, min_periods=1).mean()
    df['vol_relativo'] = df['volume'] / df['vol_medio_20d']
    
    # Volume financeiro
    df['vol_financeiro'] = df['close'] * df['volume']
    
    # Dividend Yield 12m (já vem do banco!)
    # Não precisa calcular - foi salvo durante o download
    if 'dy_12m' not in df.columns:
        df['dy_12m'] = 0.0  # Fallback se banco antigo
    
    return df


def backtest_papel(ticker: str, est: dict, 
                   data_inicio: str, data_fim: str) -> List[dict]:
    """
    Executa backtest de uma estratégia em um único papel.
    
    Algoritmo otimizado:
      1. Carrega TODOS os preços do papel de uma vez
      2. Carrega TODOS os dados fundamentalistas do papel de uma vez
      3. Itera pelos dados fundamentalistas (screening mensal)
      4. Para cada sinal, simula o trade usando dados de preços
    
    Args:
        ticker: Ticker com .SA
        est: Dict da estratégia
        data_inicio, data_fim: Período do backtest
    
    Returns:
        Lista de trades executados
    """
    database = db.get_db()
    
    # 1. Carrega TODOS os preços do papel
    df_precos = database.buscar_precos(ticker, data_inicio, data_fim)
    if df_precos.empty:
        return []
    
    df_precos["data"] = pd.to_datetime(df_precos["data"])
    df_precos = df_precos.set_index("data")
    
    # NOVO: Verifica se estratégia precisa de features técnicas
    if est.get("requer_features_tecnicas", False):
        # Estratégia técnica: calcula features e usa preços como fonte de screening
        df_precos = calcular_features_tecnicas(df_precos, ticker=ticker)
        df_precos = calcular_features_valor_relativo(df_precos)  
        df_screening = df_precos
        usa_features_tecnicas = True
    else:
        # Estratégia fundamentalista: usa dados fundamentalistas
        usa_features_tecnicas = False
        
        # 2. Carrega TODOS os dados fundamentalistas do papel
        df_fund = database.buscar_fundamentalista(ticker, data_inicio, data_fim)
    
        # CORREÇÃO: Se não tem dados históricos, usa snapshot mais recente
        if df_fund.empty:
            # Tenta buscar qualquer snapshot disponível (mais recente)
            df_fund = database.buscar_fundamentalista(ticker, "2000-01-01", "2030-12-31")
            
            if df_fund.empty:
                return []  # Realmente não tem nenhum dado
            
            # Forward-fill: replica snapshot mais recente para todo o período
            snapshot_recente = df_fund.iloc[-1]  # Pega o mais recente
            
            # Cria múltiplos snapshots (1 por trimestre) usando os mesmos valores
            datas_sinteticas = pd.date_range(start=data_inicio, end=data_fim, freq='3ME')
            
            df_fund = pd.DataFrame([snapshot_recente] * len(datas_sinteticas))
            df_fund["data"] = datas_sinteticas
            df_fund["ticker"] = ticker
        
        df_fund["data"] = pd.to_datetime(df_fund["data"])
        df_fund = df_fund.set_index("data")
        df_screening = df_fund
    
    # 3. Prepara funções da estratégia
    fn_sinal = est["fn_sinal"]
    fn_saida = est["fn_saida"]
    p = est["parametros"]
    
    # 4. Itera pelos snapshots de screening
    trades = []
    sinais_detectados = 0
    
    # CORREÇÃO CRÍTICA: Rastreia última saída para NÃO abrir trades simultâneos
    # Bug identificado: sem isso, abria múltiplos trades clonados no mesmo papel
    ultima_data_saida = pd.Timestamp("1900-01-01")
    
    for data_screening in df_screening.index:
        # Garante que data_screening é Timestamp
        if not isinstance(data_screening, pd.Timestamp):
            data_screening = pd.Timestamp(data_screening)
        
        # CORREÇÃO: Só verifica novo sinal se NÃO há trade ativo
        # Se ainda está em trade (data_screening <= ultima_data_saida), PULA!
        if data_screening <= ultima_data_saida:
            continue
        
        row_screening = df_screening.loc[data_screening]
        
        # Verifica se dispara sinal
        try:
            disparou = fn_sinal(row_screening, p)
        except Exception:
            disparou = False
        
        if not disparou:
            continue
        
        sinais_detectados += 1
        
        # Sinal disparou! Simula trade
        # IMPORTANTE: Compra na ABERTURA do próximo dia útil
        # (sinal dispara após fechamento de hoje, executa amanhã na abertura)
        datas_futuras = df_precos[df_precos.index > data_screening].index
        
        if len(datas_futuras) == 0:
            continue  # Não há dados futuros
        
        data_entrada = datas_futuras[0]
        
        # CORREÇÃO CRÍTICA: Usa OPEN do dia seguinte, não CLOSE
        # No mundo real: sinal dispara hoje após fechamento → compra amanhã na abertura
        preco_entrada = df_precos.loc[data_entrada, "open"]
        
        # Aplica slippage na entrada (realista: 0.1-0.3%)
        slippage = CFG["backtest"]["slippage_percent"]
        preco_entrada_real = preco_entrada * (1 + slippage)
        
        # Simula holding
        trade = simular_trade(
            ticker, data_entrada, preco_entrada_real,
            df_precos, df_screening, fn_saida, p
        )
        
        if trade:
            trade["estrategia"] = est["nome"]
            trades.append(trade)
            
            # ATUALIZA última data de saída para evitar trades simultâneos
            ultima_data_saida = pd.Timestamp(trade["data_saida"])
    
    # Debug: mostrar sinais vs trades
    if sinais_detectados > 0 and len(trades) == 0:
        print(f"\n   [DEBUG {est['nome']}] {sinais_detectados} sinais detectados mas nenhum trade completou")
    
    return trades


def simular_trade(ticker: str, data_entrada: pd.Timestamp, preco_entrada: float,
                  df_precos: pd.DataFrame, df_screening: pd.DataFrame,
                  fn_saida: callable, p: dict) -> Optional[dict]:
    """
    Simula um trade individual desde a entrada até a saída.
    
    Args:
        ticker: Ticker
        data_entrada: Data da compra
        preco_entrada: Preço de entrada (já com slippage)
        df_precos: DataFrame com todos os preços do papel
        df_screening: DataFrame com dados de screening (fundamentalista ou técnico)
        fn_saida: Função que determina quando sair
        p: Parâmetros da estratégia
    
    Returns:
        Dict com resultado do trade ou None se não completou
    """
    taxas = CFG["backtest"]["taxas_percent"]
    slippage = CFG["backtest"]["slippage_percent"]
    
    # Garante que data_entrada é Timestamp
    if not isinstance(data_entrada, pd.Timestamp):
        data_entrada = pd.Timestamp(data_entrada)
    
    # Itera pelos dias seguintes
    datas_futuras = df_precos[df_precos.index > data_entrada].index
    
    for data_atual in datas_futuras:
        dias_posicao = (data_atual - data_entrada).days
        preco_atual = df_precos.loc[data_atual, "close"]
        
        # Busca dados de screening mais recentes (fundamentalista ou técnico)
        screening_recentes = df_screening[df_screening.index <= data_atual]
        row_screening_atual = screening_recentes.iloc[-1] if not screening_recentes.empty else None
        
        # Verifica se deve sair
        try:
            deve_sair, motivo = fn_saida(
                data_entrada, dias_posicao,
                preco_entrada, preco_atual,
                row_screening_atual, p
            )
        except Exception:
            deve_sair, motivo = False, None
        
        if deve_sair:
            # CORREÇÃO: Vende na ABERTURA do dia seguinte
            # (sinal de saída dispara hoje após fechamento → executa amanhã na abertura)
            datas_saida_futuras = df_precos[df_precos.index > data_atual].index
            
            if len(datas_saida_futuras) == 0:
                # Não há dia seguinte, usa close de hoje (fim do backtest)
                preco_saida = preco_atual
            else:
                data_saida = datas_saida_futuras[0]
                preco_saida = df_precos.loc[data_saida, "open"]
            
            # Aplica slippage na saída
            preco_saida_real = preco_saida * (1 - slippage)
            
            # Calcula retorno
            ret_pct = 100 * (
                (preco_saida_real * (1 - taxas / 2)) /
                (preco_entrada * (1 + taxas / 2)) - 1
            )
            
            # Data de saída = dia que efetivamente vendeu (dia seguinte do sinal)
            if len(datas_saida_futuras) > 0:
                data_saida_efetiva = datas_saida_futuras[0]
            else:
                data_saida_efetiva = data_atual
            
            return {
                "ticker": ticker,
                "data_entrada": str(data_entrada.date()),
                "data_saida": str(data_saida_efetiva.date()),
                "dias": (data_saida_efetiva - data_entrada).days,
                "preco_entrada": round(preco_entrada, 2),
                "preco_saida": round(preco_saida_real, 2),
                "retorno_%": round(ret_pct, 2),
                "motivo_saida": motivo,
            }
    
    return None  # Trade não completou (não teve saída no período)


# ===========================================================================
# Backtest completo
# ===========================================================================

def backtest_completo(estrategias: List[dict], tickers: List[str]) -> Dict:
    """
    Executa backtest de múltiplas estratégias em múltiplos papéis.
    
    Returns:
        Dict com resultados por estratégia
    """
    data_inicio = CFG["backtest"]["data_inicio"]
    data_fim = CFG["backtest"]["data_fim"]
    
    print(f"\n{'='*70}")
    print(f"BACKTEST VALOR/DIVIDENDOS")
    print(f"Período: {data_inicio} até {data_fim}")
    print(f"Estratégias: {len(estrategias)}")
    print(f"Papéis: {len(tickers)}")
    print(f"{'='*70}\n")
    
    resultados = {est["nome"]: [] for est in estrategias}
    
    # Loop por PAPEL (otimizado)
    for i, ticker in enumerate(tickers, 1):
        print(f"[{i:3d}/{len(tickers)}] {ticker}...", end=" ", flush=True)
        
        try:
            # Para cada estratégia, testa neste papel
            trades_papel = 0
            
            for est in estrategias:
                trades = backtest_papel(ticker, est, data_inicio, data_fim)
                
                if trades:
                    resultados[est["nome"]].extend(trades)
                    trades_papel += len(trades)
            
            if trades_papel > 0:
                print(f"[OK] ({trades_papel} trades)")
            else:
                print("--")
        
        except Exception as e:
            print(f"✗ ({e})")
    
    print()
    return resultados


# ===========================================================================
# Métricas e relatórios
# ===========================================================================

def calcular_metricas(df_trades: pd.DataFrame) -> dict:
    """Calcula métricas consolidadas de uma estratégia"""
    if df_trades.empty:
        return None
    
    n = len(df_trades)
    taxa_acerto = (df_trades["retorno_%"] > 0).sum() / n * 100
    ret_medio = df_trades["retorno_%"].mean()
    ret_std = df_trades["retorno_%"].std()
    
    # Retorno anualizado baseado em holding médio (MÉTRICA ANTIGA - mantida para comparação)
    holding_medio_dias = df_trades["dias"].mean()
    fator_anual = 365 / holding_medio_dias if holding_medio_dias > 0 else 1
    ret_anual_simplificado = ret_medio * fator_anual
    sharpe = (ret_medio / ret_std * np.sqrt(fator_anual)) if ret_std > 0 else 0
    
    # NOVO: CAGR com Cash Drag (SELIC)
    # Simula patrimônio dia a dia considerando:
    # - Dinheiro parado rende SELIC (10%/ano conservador)
    # - Dinheiro em trade rende conforme o papel
    cagr_real = calcular_cagr_com_selic(df_trades)
    
    # Equity curve e drawdown
    # CORREÇÃO: Calcula equity assumindo trades INDEPENDENTES (não sequenciais)
    df_trades = df_trades.sort_values("data_entrada").reset_index(drop=True)
    
    # Cada trade é independente, retorno médio é a melhor métrica
    # Para MaxDD, usa o pior trade individual
    max_dd = df_trades["retorno_%"].min()
    
    # Se quiser equity curve sequencial (como se reinvestisse tudo):
    # df_trades["equity"] = (1 + df_trades["retorno_%"] / 100).cumprod()
    # df_trades["peak"] = df_trades["equity"].cummax()  
    # df_trades["dd"] = (df_trades["equity"] / df_trades["peak"] - 1) * 100
    # max_dd = df_trades["dd"].min()
    
    return {
        "n_trades": n,
        "taxa_acerto_%": round(taxa_acerto, 1),
        "ret_medio_%": round(ret_medio, 2),
        "ret_anual_%": round(ret_anual_simplificado, 1),  # Métrica antiga
        "cagr_real_%": round(cagr_real, 2),  # NOVA: CAGR com SELIC
        "sharpe": round(sharpe, 2),
        "holding_medio_dias": round(holding_medio_dias, 0),
        "max_dd_%": round(max_dd, 1),
        "melhor_trade_%": round(df_trades["retorno_%"].max(), 2),
        "pior_trade_%": round(df_trades["retorno_%"].min(), 2),
    }


def calcular_features_valor_relativo(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calcula o prêmio de Yield em relação à própria história do papel.
    """
    # Média móvel de 2 anos (504 dias úteis) para o DY
    df['dy_med_2y'] = df['dy_12m'].rolling(window=504, min_periods=100).mean()
    df['dy_std_2y'] = df['dy_12m'].rolling(window=504, min_periods=100).std()
    
    # Z-Score: Quão longe o DY atual está da média (em Desvios Padrões)
    # Se Z > 2, o Yield está anomalamente alto (preço caiu demais vs dividendos mantidos)
    df['dy_zscore'] = (df['dy_12m'] - df['dy_med_2y']) / df['dy_std_2y']
    
    # Filtro de Tendência: Média Móvel de 20 dias (Bollinger de Curto Prazo)
    df['sma_20'] = df['close'].rolling(window=20).mean()
    df['sma_50'] = df['close'].rolling(window=50).mean()
    
    return df

def calcular_cagr_com_selic(df_trades: pd.DataFrame, 
                            capital_inicial: float = 100000.0,
                            selic_anual: float = 0.10,
                            taxas_corretagem: float = 0.0) -> float:
    if df_trades.empty: return 10.0 # Retorno da SELIC pura
    
    # 1. Preparar linha do tempo diária
    data_min = pd.to_datetime(CFG["backtest"]["data_inicio"])
    data_max = pd.to_datetime(CFG["backtest"]["data_fim"])
    datas = pd.date_range(data_min, data_max, freq='B') # Dias úteis
    
    # 2. Rastrear saldo e alocação
    saldo_caixa = capital_inicial
    ativos_em_carteira = [] # Lista de dicts: {data_saida, valor_investido, retorno}
    equity_diaria = []
    
    max_ativos = 4  # Limite de exposição simultânea (ajustável)

    selic_diaria = (1 + selic_anual)**(1/252) - 1
    alocacao_fixa = capital_inicial / max_ativos

    for hoje in datas:
        # A. Liberar capital de trades que venceram hoje
        for trade in ativos_em_carteira[:]:
            if trade['data_saida'] <= hoje:
                saldo_caixa += trade['valor_final']
                ativos_em_carteira.remove(trade)
        
        # B. Checar se há novos sinais para HOJE
        sinais_hoje = df_trades[pd.to_datetime(df_trades['data_entrada']) == hoje]
        for _, sinal in sinais_hoje.iterrows():
            if len(ativos_em_carteira) < max_ativos and saldo_caixa >= alocacao_fixa:
                # Executa a compra
                saldo_caixa -= alocacao_fixa
                valor_final = alocacao_fixa * (1 + sinal['retorno_%']/100)
                ativos_em_carteira.append({
                    'data_saida': pd.to_datetime(sinal['data_saida']),
                    'valor_final': valor_final
                })
        
        # C. O saldo em caixa rende SELIC
        saldo_caixa *= (1 + selic_diaria)
        
        # D. Patrimônio Total = Caixa + Valor de mercado dos ativos (simplificado para o final)
        equity_hoje = saldo_caixa + sum(alocacao_fixa for _ in ativos_em_carteira)
        equity_diaria.append(equity_hoje)

    # 3. CAGR Final
    valor_final = equity_diaria[-1]
    anos = (data_max - data_min).days / 365.25
    return ((valor_final / capital_inicial)**(1/anos) - 1) * 100


def calcular_cagr_com_selic_DETALHADO(df_trades: pd.DataFrame,
                                       capital_inicial: float = 100000.0,
                                       selic_anual: float = 0.10) -> dict:
    """
    Versão DETALHADA para debug - retorna breakdown completo.
    """
    if df_trades.empty:
        return {"cagr_real": 0.0}
    
    df = df_trades.copy()
    df["data_entrada"] = pd.to_datetime(df["data_entrada"])
    df["data_saida"] = pd.to_datetime(df["data_saida"])
    
    data_inicio = df["data_entrada"].min()
    data_fim = df["data_saida"].max()
    anos_totais = (data_fim - data_inicio).days / 365.25
    
    if anos_totais <= 0:
        return {"cagr_real": 0.0}
    
    # Retorno médio geométrico (para referência)
    retornos = df["retorno_%"].values
    n_trades = len(retornos)
    
    produto = 1.0
    for ret in retornos:
        produto *= (1 + ret / 100)
    
    retorno_medio_geom = (produto ** (1 / n_trades) - 1) * 100
    
    # Retorno diário médio
    retornos_diarios = []
    for _, trade in df.iterrows():
        if trade["dias"] > 0:
            ret_diario = (1 + trade["retorno_%"]/100) ** (1 / trade["dias"]) - 1
            retornos_diarios.append(ret_diario)
    
    ret_diario_medio = np.mean(retornos_diarios) if retornos_diarios else 0
    
    # Frequência e exposição
    trades_por_ano = n_trades / anos_totais
    dias_por_trade = df["dias"].mean()
    dias_em_trades_por_ano = trades_por_ano * dias_por_trade
    proporcao_tempo_em_trades = min(dias_em_trades_por_ano / 365.0, 1.0)
    
    # Retorno anual trades (baseado em retorno diário)
    retorno_anual_trades = ((1 + ret_diario_medio) ** 365 - 1) * 100
    
    # CAGR real
    cagr_real = (proporcao_tempo_em_trades * retorno_anual_trades + 
                 (1 - proporcao_tempo_em_trades) * (selic_anual * 100))
    
    return {
        "cagr_real": cagr_real,
        "retorno_medio_geometrico": retorno_medio_geom,
        "retorno_diario_medio": ret_diario_medio * 100,
        "trades_por_ano": trades_por_ano,
        "dias_por_trade": dias_por_trade,
        "dias_em_trades_por_ano": dias_em_trades_por_ano,
        "proporcao_tempo_em_trades": proporcao_tempo_em_trades * 100,
        "proporcao_tempo_parado": (1 - proporcao_tempo_em_trades) * 100,
        "retorno_anual_quando_em_trades": retorno_anual_trades,
        "contribuicao_trades": proporcao_tempo_em_trades * retorno_anual_trades,
        "contribuicao_selic": (1 - proporcao_tempo_em_trades) * (selic_anual * 100),
    }








def imprimir_relatorio(resultados: Dict):
    """Imprime relatório comparativo das estratégias"""
    print(f"\n{'='*80}")
    print("RESULTADOS")
    print(f"{'='*80}\n")
    
    # Prepara dados para tabela
    linhas = []
    
    for nome, trades in resultados.items():
        df = pd.DataFrame(trades)
        m = calcular_metricas(df)
        
        if m:
            linhas.append({
                "Estrategia": nome,
                "Trades": m["n_trades"],
                "Taxa%": f"{m['taxa_acerto_%']:.1f}",
                "Ret/Trade%": f"{m['ret_medio_%']:.2f}",
                "CAGR Real%": f"{m['cagr_real_%']:.2f}",  # NOVO!
                "Ret Anual%": f"{m['ret_anual_%']:.1f}",  # Antigo (para comparação)
                "Sharpe": f"{m['sharpe']:.2f}",
                "Hold(d)": f"{m['holding_medio_dias']:.0f}",
                "MaxDD%": f"{m['max_dd_%']:.1f}",
            })
    
    if linhas:
        df_relatorio = pd.DataFrame(linhas)
        print(df_relatorio.to_string(index=False))
        print()
        
        # Explicação das métricas
        print(f"{'='*80}")
        print("LEGENDA DAS METRICAS:")
        print(f"{'='*80}")
        print("CAGR Real%  : Retorno anualizado HONESTO considerando SELIC (10%/ano) no capital parado")
        print("Ret Anual%  : Retorno simplificado (metrica antiga, ignora cash drag)")
        print("              >> Use CAGR Real% para decisoes! <<")
        print(f"{'='*80}\n")
        
        # DEBUG DETALHADO
        for nome, trades in resultados.items():
            df = pd.DataFrame(trades)
            
            # Calcula versão detalhada
            detalhes = calcular_cagr_com_selic_DETALHADO(df)
            
            if detalhes:
                print(f"\n{nome} - BREAKDOWN DETALHADO:")
                print(f"{'='*80}")
                print(f"  Trades totais: {len(df)}")
                print(f"  Trades por ano: {detalhes['trades_por_ano']:.2f}")
                print(f"  Holding medio: {detalhes['dias_por_trade']:.0f} dias")
                print(f"  Retorno medio geometrico: {detalhes['retorno_medio_geometrico']:+.2f}%")
                print(f"  Retorno DIARIO medio: {detalhes['retorno_diario_medio']:+.4f}%/dia")
                print(f"  Retorno anual (quando em trades): {detalhes['retorno_anual_quando_em_trades']:+.2f}%")
                print(f"  Dias em trades/ano: {detalhes['dias_em_trades_por_ano']:.0f} (overlap={detalhes['dias_em_trades_por_ano']>365})")
                print(f"  Tempo em trades: {detalhes['proporcao_tempo_em_trades']:.1f}%")
                print(f"  Tempo em cash (SELIC): {detalhes['proporcao_tempo_parado']:.1f}%")
                print(f"  Contribuicao trades: {detalhes['contribuicao_trades']:+.2f}%")
                print(f"  Contribuicao SELIC: {detalhes['contribuicao_selic']:+.2f}%")
                print(f"  CAGR REAL: {detalhes['cagr_real']:+.2f}%/ano")
        
        # Análise SELIC
        print(f"\n{'='*80}")
        print("AVALIACAO vs BENCHMARK:")
        print(f"{'='*80}")
        
        for nome, trades in resultados.items():
            df = pd.DataFrame(trades)
            m = calcular_metricas(df)
            
            if m:
                print(f"\n{nome}:")
                print(f"  CAGR Real: {m['cagr_real_%']:.2f}%/ano")
                print(f"  SELIC (benchmark): 10.00%/ano")
                premio_risco = m['cagr_real_%'] - 10.0
                print(f"  Premio de Risco: {premio_risco:+.2f}%")
                
                if premio_risco >= 5.0:
                    print(f"  Avaliacao: EXCELENTE (bateu SELIC + 5%)")
                elif premio_risco >= 3.0:
                    print(f"  Avaliacao: BOM (bateu SELIC + 3%)")
                elif premio_risco >= 0:
                    print(f"  Avaliacao: OK (bateu SELIC)")
                else:
                    print(f"  Avaliacao: RUIM (nao bateu SELIC)")
        
        print()

    else:
        print("Nenhum trade executado.\n")
    
    print("="*70 + "\n")


# ===========================================================================
# CLI
# ===========================================================================

def main():
    parser = argparse.ArgumentParser(description="Screening e backtest de estrategias valor")
    parser.add_argument("--estrategia", help="Nome da estrategia a testar")
    parser.add_argument("--ticker", help="Ticker unico para debug")
    parser.add_argument("--universo", help="Arquivo com lista de tickers")
    parser.add_argument("--stress-test", action="store_true", 
                       help="Executa stress test (analise de sensibilidade)")
    
    args = parser.parse_args()
    
    # MODO STRESS TEST
    if args.stress_test:
        if not args.estrategia:
            print("Erro: --stress-test requer --estrategia")
            return
        
        print("\nMODO: STRESS TEST")
        print("Executando analise de sensibilidade...")
        
        # Pode customizar variacoes aqui se desejar
        # variacoes_custom = {
        #     "rsi_max": [25, 28, 30, 32],
        #     "dy_12m_min": [0.03, 0.04, 0.05]
        # }
        
        df_resultados = stress_test_estrategia(
            args.estrategia,
            variacoes=None,  # None = usa variacoes padrao
            verbose=True
        )
        
        # Salva resultados em CSV
        output_file = f"stress_test_{args.estrategia}_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.csv"
        df_resultados.to_csv(output_file, index=False)
        print(f"\nResultados salvos em: {output_file}")
        return
    
    # MODO NORMAL (backtest)
    # Carrega estrategias
    if args.estrategia:
        estrategias = [carregar_estrategia(args.estrategia)]
    else:
        estrategias = carregar_estrategias_ativas()
    
    if not estrategias:
        print("Erro: Nenhuma estrategia carregada.")
        return
    
    # Carrega universo
    if args.ticker:
        tickers = [args.ticker]
    elif args.universo:
        with open(args.universo, encoding='utf-8') as f:
            tickers = [line.strip() for line in f if line.strip()]
    else:
        arquivo_universo = CFG["universo"]["arquivo"]
        try:
            with open(arquivo_universo) as f:
                tickers = [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            print(f"Erro: {arquivo_universo} nao encontrado.")
            return
    
    # Executa backtest
    resultados = backtest_completo(estrategias, tickers)
    
    # Relatório
    imprimir_relatorio(resultados)


# ===========================================================================
# Funções auxiliares para uso externo
# ===========================================================================

def carregar_universo() -> List[str]:
    """
    Carrega lista de tickers do universo de investimento.
    
    Prioridade:
    1. Lista fixa em CFG["universo"]["tickers_ativos"] (se existir)
    2. Arquivo em CFG["universo"]["arquivo"]
    
    Returns:
        Lista de tickers (ex: ["PETR4.SA", "VALE3.SA", ...])
    """
    # Tenta lista fixa primeiro (útil para testes)
    if "tickers_ativos" in CFG["universo"]:
        tickers_fixos = CFG["universo"]["tickers_ativos"]
        if tickers_fixos:  # Se não for lista vazia
            return tickers_fixos
    
    # Senão, carrega de arquivo
    arquivo_universo = CFG["universo"]["arquivo"]
    try:
        with open(arquivo_universo, encoding='utf-8') as f:
            tickers = [line.strip() for line in f if line.strip()]
        return tickers
    except FileNotFoundError:
        print(f"Erro: {arquivo_universo} nao encontrado.")
        return []


# ===========================================================================
# Stress Test - Analise de Sensibilidade
# ===========================================================================

def stress_test_estrategia(estrategia_nome: str, variacoes: dict = None, verbose: bool = True):
    """
    Analisa sensibilidade da estrategia variando parametros criticos.
    
    Testa como pequenas mudancas nos parametros afetam:
    - Numero de trades
    - Taxa de acerto
    - Retorno medio por trade
    - Retorno anualizado
    - Sharpe ratio
    
    Args:
        estrategia_nome: Nome da estrategia (ex: 'valor_tecnico_dividendos')
        variacoes: Dict com parametros e valores a testar. Se None, usa variacoes padrao.
        verbose: Se True, imprime progresso
    
    Exemplo de variacoes customizadas:
        {
            "rsi_max": [25, 28, 30, 32],
            "dy_12m_min": [0.03, 0.04, 0.05],
            "preco_vs_max_52w_max": [0.65, 0.70, 0.75]
        }
    
    Returns:
        DataFrame com resultados de todas as combinacoes testadas
    """
    import itertools
    from datetime import datetime
    
    # Carrega estrategia base
    est_base = carregar_estrategia(estrategia_nome)
    p_base = est_base["parametros"]
    
    # Define variacoes padrao se nao fornecidas
    if variacoes is None:
        # Variacoes padrao: +/- 10-15% do valor base
        variacoes = {}
        
        # RSI: varia +/- 2 pontos
        if "rsi_max" in p_base:
            rsi_base = p_base["rsi_max"]
            variacoes["rsi_max"] = [rsi_base - 2, rsi_base, rsi_base + 2]
        
        # DY: varia +/- 1 ponto percentual
        if "dy_12m_min" in p_base:
            dy_base = p_base["dy_12m_min"]
            variacoes["dy_12m_min"] = [
                max(0, dy_base - 0.01),
                dy_base,
                dy_base + 0.01
            ]
        
        # Preco vs max 52w: varia +/- 5%
        if "preco_vs_max_52w_max" in p_base:
            max52w_base = p_base["preco_vs_max_52w_max"]
            variacoes["preco_vs_max_52w_max"] = [
                max52w_base - 0.05,
                max52w_base,
                max52w_base + 0.05
            ]
    
    # Carrega universo e config
    tickers = carregar_universo()
    data_inicio = CFG["backtest"]["data_inicio"]
    data_fim = CFG["backtest"]["data_fim"]
    
    # Gera todas as combinacoes de parametros
    params_nomes = list(variacoes.keys())
    params_valores = list(variacoes.values())
    combinacoes = list(itertools.product(*params_valores))
    
    total_combinacoes = len(combinacoes)
    
    if verbose:
        print("\n" + "="*80)
        print("STRESS TEST - ANALISE DE SENSIBILIDADE")
        print("="*80)
        print(f"Estrategia: {estrategia_nome}")
        print(f"Periodo: {data_inicio} ate {data_fim}")
        print(f"Tickers: {len(tickers)}")
        print(f"Parametros testados: {', '.join(params_nomes)}")
        print(f"Total de combinacoes: {total_combinacoes}")
        print("="*80 + "\n")
        
        # Header da tabela
        header = "|"
        for nome in params_nomes:
            header += f" {nome:^10s} |"
        header += " Trades | Taxa % | Ret/Trade% | Ret Ano% | Sharpe | MaxDD% |"
        print(header)
        print("-" * len(header))
    
    # Lista para armazenar resultados
    resultados = []
    
    # Testa cada combinacao
    for idx, comb in enumerate(combinacoes, 1):
        # Cria estrategia de teste com parametros modificados
        p_teste = p_base.copy()
        for i, nome in enumerate(params_nomes):
            p_teste[nome] = comb[i]
        
        est_teste = est_base.copy()
        est_teste["parametros"] = p_teste
        est_teste["nome"] = f"{estrategia_nome}_teste_{idx}"
        
        # Executa backtest
        try:
            todos_trades = []
            for ticker in tickers:
                trades_ticker = backtest_papel(ticker, est_teste, data_inicio, data_fim)
                todos_trades.extend(trades_ticker)
            
            # Calcula metricas
            if len(todos_trades) > 0:
                df_trades = pd.DataFrame(todos_trades)
                metricas = calcular_metricas(df_trades)
                
                # Prepara resultado
                resultado = {}
                for i, nome in enumerate(params_nomes):
                    resultado[nome] = comb[i]
                
                resultado.update({
                    "n_trades": metricas["n_trades"],
                    "taxa_acerto_%": metricas["taxa_acerto_%"],
                    "ret_medio_%": metricas["ret_medio_%"],
                    "ret_anual_%": metricas["ret_anual_%"],
                    "sharpe": metricas.get("sharpe", 0),
                    "maxdd_%": metricas.get("maxdd_%", 0),
                })
                
                resultados.append(resultado)
                
                # Imprime linha da tabela
                if verbose:
                    linha = "|"
                    for val in comb:
                        if isinstance(val, float):
                            linha += f" {val:^10.2f} |"
                        else:
                            linha += f" {val:^10} |"
                    linha += f" {metricas['n_trades']:^6d} |"
                    linha += f" {metricas['taxa_acerto_%']:^6.1f} |"
                    linha += f" {metricas['ret_medio_%']:^11.2f} |"
                    linha += f" {metricas['ret_anual_%']:^9.1f} |"
                    linha += f" {metricas.get('sharpe', 0):^6.2f} |"
                    linha += f" {metricas.get('maxdd_%', 0):^7.1f} |"
                    print(linha)
            
            else:
                # Sem trades
                resultado = {}
                for i, nome in enumerate(params_nomes):
                    resultado[nome] = comb[i]
                resultado.update({
                    "n_trades": 0,
                    "taxa_acerto_%": 0,
                    "ret_medio_%": 0,
                    "ret_anual_%": 0,
                    "sharpe": 0,
                    "maxdd_%": 0,
                })
                resultados.append(resultado)
                
                if verbose:
                    linha = "|"
                    for val in comb:
                        if isinstance(val, float):
                            linha += f" {val:^10.2f} |"
                        else:
                            linha += f" {val:^10} |"
                    linha += " (sem trades)".ljust(len(header) - len(linha) - 1)
                    print(linha)
        
        except Exception as e:
            if verbose:
                print(f"[X] Erro na combinacao {idx}: {e}")
            continue
    
    # Converte para DataFrame
    df_resultados = pd.DataFrame(resultados)
    
    if verbose:
        print("\n" + "="*80)
        print("ANALISE DE SENSIBILIDADE")
        print("="*80)
        
        # Encontra melhor combinacao por metrica
        if not df_resultados.empty:
            print("\nMELHORES COMBINACOES:")
            print("-" * 80)
            
            # Melhor Sharpe
            if "sharpe" in df_resultados.columns:
                idx_melhor_sharpe = df_resultados["sharpe"].idxmax()
                melhor_sharpe = df_resultados.loc[idx_melhor_sharpe]
                print("\n1. Melhor Sharpe Ratio:")
                for nome in params_nomes:
                    print(f"   {nome}: {melhor_sharpe[nome]}")
                print(f"   Sharpe: {melhor_sharpe['sharpe']:.2f}")
                print(f"   Ret Anual: {melhor_sharpe['ret_anual_%']:.1f}%")
                print(f"   Taxa: {melhor_sharpe['taxa_acerto_%']:.1f}%")
            
            # Melhor retorno anual
            idx_melhor_ret = df_resultados["ret_anual_%"].idxmax()
            melhor_ret = df_resultados.loc[idx_melhor_ret]
            print("\n2. Melhor Retorno Anual:")
            for nome in params_nomes:
                print(f"   {nome}: {melhor_ret[nome]}")
            print(f"   Ret Anual: {melhor_ret['ret_anual_%']:.1f}%")
            print(f"   Sharpe: {melhor_ret.get('sharpe', 0):.2f}")
            print(f"   Taxa: {melhor_ret['taxa_acerto_%']:.1f}%")
            
            # Melhor taxa de acerto
            idx_melhor_taxa = df_resultados["taxa_acerto_%"].idxmax()
            melhor_taxa = df_resultados.loc[idx_melhor_taxa]
            print("\n3. Melhor Taxa de Acerto:")
            for nome in params_nomes:
                print(f"   {nome}: {melhor_taxa[nome]}")
            print(f"   Taxa: {melhor_taxa['taxa_acerto_%']:.1f}%")
            print(f"   Ret Anual: {melhor_taxa['ret_anual_%']:.1f}%")
            print(f"   Sharpe: {melhor_taxa.get('sharpe', 0):.2f}")
            
            # Analise de estabilidade
            print("\n" + "="*80)
            print("ESTABILIDADE (Variabilidade dos Resultados)")
            print("="*80)
            print(f"Retorno Anual - Media: {df_resultados['ret_anual_%'].mean():.1f}%")
            print(f"                Std: {df_resultados['ret_anual_%'].std():.1f}%")
            print(f"                Min/Max: {df_resultados['ret_anual_%'].min():.1f}% / {df_resultados['ret_anual_%'].max():.1f}%")
            print(f"\nTaxa Acerto -   Media: {df_resultados['taxa_acerto_%'].mean():.1f}%")
            print(f"                Std: {df_resultados['taxa_acerto_%'].std():.1f}%")
            print(f"                Min/Max: {df_resultados['taxa_acerto_%'].min():.1f}% / {df_resultados['taxa_acerto_%'].max():.1f}%")
            
            # Avaliacao de robustez
            cv_ret = df_resultados['ret_anual_%'].std() / df_resultados['ret_anual_%'].mean()
            cv_taxa = df_resultados['taxa_acerto_%'].std() / df_resultados['taxa_acerto_%'].mean()
            
            print(f"\nCoeficiente de Variacao:")
            print(f"  Retorno: {cv_ret:.2f} {'(ROBUSTO)' if cv_ret < 0.3 else '(SENSIVEL)'}")
            print(f"  Taxa: {cv_taxa:.2f} {'(ROBUSTO)' if cv_taxa < 0.15 else '(SENSIVEL)'}")
            
        print("\n" + "="*80)
        print(f"Teste concluido: {len(df_resultados)} combinacoes analisadas")
        print("="*80 + "\n")
    
    return df_resultados


if __name__ == "__main__":
    main()