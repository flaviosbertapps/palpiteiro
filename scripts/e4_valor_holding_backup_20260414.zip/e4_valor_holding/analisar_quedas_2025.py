"""
Análise de Quedas em 2025
==========================
Verifica se papéis caíram 30-50% em 2025
"""

import sqlite3
import pandas as pd
import numpy as np

print("="*70)
print("ANÁLISE: Houve quedas em 2025?")
print("="*70)

conn = sqlite3.connect("data/precos.db")

tickers = [
    "PETR4.SA", "VALE3.SA", "ITUB4.SA", "BBDC4.SA", 
    "ABEV3.SA", "CSNA3.SA", "LREN3.SA", "MGLU3.SA",
    "BBAS3.SA", "WEGE3.SA", "RENT3.SA", "SUZB3.SA"
]

print("\nVerificando quedas de 30%+ do topo de 52 semanas:\n")

for ticker in tickers:
    query = f"""
    SELECT data, close, high, volume
    FROM precos
    WHERE ticker = '{ticker}'
      AND data >= '2024-01-01'
      AND data <= '2026-03-19'
    ORDER BY data
    """
    
    df = pd.read_sql(query, conn, parse_dates=['data'])
    
    if len(df) < 252:
        continue
    
    # Calcula features
    df['max_52w'] = df['high'].rolling(window=252, min_periods=1).max()
    df['preco_vs_max_52w'] = df['close'] / df['max_52w']
    
    # Calcula RSI
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    df['rsi'] = 100 - (100 / (1 + rs))
    
    # Filtra 2025
    df_2025 = df[df['data'] >= '2025-01-01'].copy()
    
    if df_2025.empty:
        continue
    
    # Encontra dias com queda 30-50%
    condicao_queda = (df_2025['preco_vs_max_52w'] >= 0.50) & (df_2025['preco_vs_max_52w'] <= 0.70)
    dias_queda = condicao_queda.sum()
    
    # Menor preço vs max
    min_ratio = df_2025['preco_vs_max_52w'].min()
    max_queda_pct = (1 - min_ratio) * 100
    
    # RSI mínimo
    rsi_min = df_2025['rsi'].min()
    
    # Dias com RSI < 28
    dias_rsi_baixo = (df_2025['rsi'] < 28).sum()
    
    print(f"{ticker:12s}:")
    print(f"  Maior queda: {max_queda_pct:5.1f}% (preço vs max 52w: {min_ratio*100:.1f}%)")
    print(f"  RSI mínimo: {rsi_min:5.1f}")
    print(f"  Dias com queda 30-50%: {dias_queda}")
    print(f"  Dias com RSI < 28: {dias_rsi_baixo}")
    
    # Encontra melhor oportunidade
    candidatos = df_2025[
        (df_2025['preco_vs_max_52w'] >= 0.50) &
        (df_2025['preco_vs_max_52w'] <= 0.70) &
        (df_2025['rsi'] < 28)
    ]
    
    if not candidatos.empty:
        print(f"  ✓ {len(candidatos)} dias atenderam critérios (queda 30-50% + RSI < 28)")
        print(f"    Melhores datas:")
        for idx, row in candidatos.head(3).iterrows():
            print(f"      {row['data'].date()}: Preço R$ {row['close']:.2f}, RSI {row['rsi']:.1f}")
    else:
        print(f"  — Nunca teve queda 30-50% + RSI < 28 juntos")
    
    print()

conn.close()

print("="*70)
print("CONCLUSÃO")
print("="*70)
print("""
Se NENHUM papel teve dias com:
  - Queda 30-50% do topo
  - E RSI < 28
  
Então é NORMAL não ter trades em 2025!

Estratégia de mean reversion só funciona em QUEDAS.
Se 2025 foi ano de alta, não há oportunidades.

Isso não é problema da estratégia!
É característica: só opera quando há setup perfeito.
""")