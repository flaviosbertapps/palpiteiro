"""
Teste isolado: Download com DY
================================
Testa APENAS 1 ticker para ver se DY funciona.
"""

import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta

print("="*70)
print("TESTE ISOLADO: Download com DY")
print("="*70)

ticker = "PETR4.SA"
anos = 10

print(f"\nBaixando {ticker} (últimos {anos} anos)...")

# Busca dados
fim = datetime.now()
inicio = fim - timedelta(days=anos * 365)

acao = yf.Ticker(ticker)
hist = acao.history(start=inicio, end=fim)

print(f"  Preços: {len(hist)} dias")

# Busca dividendos
dividendos = acao.dividends

if dividendos.empty:
    print("  ✗ Sem dividendos!")
    exit()

print(f"  Dividendos: {len(dividendos)} pagamentos")

# Remove timezone
print("\n1. REMOVENDO TIMEZONE:")
print(f"  Dividendos antes: {dividendos.index[0]} (tz={dividendos.index[0].tz})")

dividendos.index = dividendos.index.tz_localize(None)

print(f"  Dividendos depois: {dividendos.index[0]} (tz={dividendos.index[0].tz})")

# Testa 5 datas recentes
print("\n2. TESTANDO CÁLCULO DE DY:")
print("-" * 70)

ultimas_datas = hist.tail(5).index

for data in ultimas_datas:
    # Remove timezone
    if hasattr(data, 'tz_localize'):
        data_naive = data.tz_localize(None)
    else:
        data_naive = data
    
    # 12 meses atrás
    data_12m = data_naive - timedelta(days=365)
    
    # Soma dividendos
    soma = 0.0
    for div_data, div_valor in dividendos.items():
        if data_12m < div_data <= data_naive:
            soma += div_valor
    
    # Calcula DY
    preco = hist.loc[data, 'Close']
    dy = (soma / preco) if preco > 0 else 0
    
    print(f"{data.date()}: Preço R$ {preco:6.2f}, Divs 12m R$ {soma:6.4f}, DY = {dy*100:5.2f}%")

print("\n" + "="*70)
print("RESULTADO")
print("="*70)

if soma > 0:
    print("""
✓ CÁLCULO DE DY FUNCIONOU!

Agora pode baixar todos:
  rm data/precos.db
  python e4_baixar_todos_precos.py

Deve mostrar:
  [1/28] PETR4.SA... ✓ (2787 dias, 2456 com DY)
                                       ↑ isso!
""")
else:
    print("""
✗ AINDA NÃO FUNCIONOU!

Possíveis causas:
1. Timezone ainda está dando problema
2. Comparação de datas não está funcionando
3. yfinance retornou dividendos em formato diferente

Me mostre a saída completa deste teste.
""")