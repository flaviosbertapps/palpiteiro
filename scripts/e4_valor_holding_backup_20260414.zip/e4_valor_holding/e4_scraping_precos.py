"""
e4_scraping_precos.py
=====================
Scraper de preços históricos usando yfinance (gratuito).

Coleta:
  - OHLCV diário de 2015 até hoje
  - Armazena em data/precos.db

Uso:
    python e4_scraping_precos.py --ticker PETR4.SA
    python e4_scraping_precos.py --todos
"""

import json
from datetime import datetime
from typing import List
import yfinance as yf
import pandas as pd

import e4_database as db

# Carregar configuração
with open("e4_config.json") as f:
    CFG = json.load(f)


# ===========================================================================
# Scraping
# ===========================================================================

def scrape_precos_ticker(ticker: str, data_inicio: str = None, data_fim: str = None) -> int:
    """
    Baixa preços históricos de um ticker via yfinance.
    
    Args:
        ticker: Ticker com sufixo .SA (ex: PETR4.SA)
        data_inicio: Data inicial (YYYY-MM-DD) ou None para usar config
        data_fim: Data final (YYYY-MM-DD) ou None para hoje
    
    Returns:
        Número de dias baixados
    """
    if data_inicio is None:
        data_inicio = CFG['backtest']['data_inicio']
    
    if data_fim is None:
        data_fim = datetime.today().strftime("%Y-%m-%d")
    
    try:
        # Download via yfinance
        df = yf.download(
            ticker,
            start=data_inicio,
            end=data_fim,
            progress=False            
        )
        
        if df.empty:
            return 0
        
        # Prepara dados para inserção
        dados = []
        for data, row in df.iterrows():
            dados.append({
                "ticker": ticker,
                "data": data.strftime("%Y-%m-%d"),
                "open": row['Open'].item() if hasattr(row['Open'], 'item') else float(row['Open']),
                "high": row['High'].item() if hasattr(row['High'], 'item') else float(row['High']),
                "low": row['Low'].item() if hasattr(row['Low'], 'item') else float(row['Low']),
                "close": row['Close'].item() if hasattr(row['Close'], 'item') else float(row['Close']),
                "volume": row['Volume'].item() if hasattr(row['Volume'], 'item') else int(row['Volume'])
            })
        
        # Salva no banco
        database = db.get_db()
        database.inserir_precos(dados)
        
        return len(dados)
    
    except Exception as e:
        print(f"   ✗ Erro: {e}")
        return 0


def scrape_precos_universo(tickers: List[str], data_inicio: str = None) -> int:
    """
    Baixa preços históricos de uma lista de tickers.
    
    Args:
        tickers: Lista de tickers com .SA
        data_inicio: Data inicial ou None
    
    Returns:
        Número de tickers processados com sucesso
    """
    if data_inicio is None:
        data_inicio = CFG['backtest']['data_inicio']
    
    data_fim = datetime.today().strftime("%Y-%m-%d")
    
    print(f"\n{'='*70}")
    print(f"SCRAPING PREÇOS - {len(tickers)} tickers")
    print(f"Período: {data_inicio} até {data_fim}")
    print(f"{'='*70}\n")
    
    sucesso = 0
    
    for i, ticker in enumerate(tickers, 1):
        print(f"[{i:3d}/{len(tickers)}] {ticker}...", end=" ", flush=True)
        
        n_dias = scrape_precos_ticker(ticker, data_inicio, data_fim)
        
        if n_dias > 0:
            print(f"✓ ({n_dias} dias)")
            sucesso += 1
        else:
            print("✗")
    
    print(f"\n{'='*70}")
    print(f"✓ Concluído: {sucesso}/{len(tickers)} tickers processados")
    print(f"{'='*70}\n")
    
    return sucesso


def atualizar_precos_recentes(tickers: List[str], dias_recentes: int = 30) -> int:
    """
    Atualiza apenas os últimos N dias de preços (mais rápido).
    
    Args:
        tickers: Lista de tickers
        dias_recentes: Quantos dias para trás atualizar
    
    Returns:
        Número de tickers atualizados
    """
    from datetime import timedelta
    
    data_inicio = (datetime.today() - timedelta(days=dias_recentes)).strftime("%Y-%m-%d")
    
    print(f"\nAtualizando últimos {dias_recentes} dias...")
    return scrape_precos_universo(tickers, data_inicio)


# ===========================================================================
# CLI
# ===========================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Scraper de preços históricos (yfinance)")
    parser.add_argument("--ticker", help="Ticker único (ex: PETR4.SA)")
    parser.add_argument("--universo", help="Arquivo com lista de tickers")
    parser.add_argument("--todos", action="store_true", help="Baixa todos do universo padrão")
    parser.add_argument("--atualizar", action="store_true", help="Atualiza apenas últimos 30 dias")
    parser.add_argument("--inicio", help="Data início (YYYY-MM-DD)")
    
    args = parser.parse_args()
    
    if args.ticker:
        # Ticker único
        print(f"\nBaixando {args.ticker}...\n")
        n_dias = scrape_precos_ticker(args.ticker, args.inicio)
        
        if n_dias > 0:
            print(f"✓ {n_dias} dias salvos no banco.")
        else:
            print("✗ Falha ao baixar dados.")
    
    elif args.universo or args.todos:
        # Lista de tickers
        if args.todos:
            arquivo = CFG['universo']['arquivo']
        else:
            arquivo = args.universo
        
        try:
            with open(arquivo) as f:
                tickers = [line.strip() for line in f if line.strip()]
            
            if args.atualizar:
                atualizar_precos_recentes(tickers)
            else:
                scrape_precos_universo(tickers, args.inicio)
        
        except FileNotFoundError:
            print(f"Erro: Arquivo '{arquivo}' não encontrado.")
    
    else:
        parser.print_help()