# -*- coding: utf-8 -*-
"""
e4_database.py
==============
Gerenciador de banco de dados SQLite para armazenar:
  - Dados fundamentalistas (P/L, DY, ROE, etc.)
  - Precos historicos (OHLCV)

Estrutura:
  - fundamentalista.db: 1 tabela com dados fundamentais por ticker/data
  - precos.db: 1 tabela com precos OHLCV por ticker/data
"""

import sys
import os

# SOLUCAO ROBUSTA PARA WINDOWS
if sys.platform == 'win32':
    try:
        import io
        if sys.stdout.encoding != 'cp1252':
            sys.stdout = io.TextIOWrapper(
                sys.stdout.buffer, 
                encoding='cp1252', 
                errors='replace',
                line_buffering=True
            )
        if sys.stderr.encoding != 'cp1252':
            sys.stderr = io.TextIOWrapper(
                sys.stderr.buffer, 
                encoding='cp1252', 
                errors='replace',
                line_buffering=True
            )
    except (AttributeError, ValueError):
        pass

import sqlite3
import json
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
import pandas as pd

# Carregar configuracao
with open("e4_config.json", encoding='utf-8') as f:
    CFG = json.load(f)


# ===========================================================================
# Schema das tabelas
# ===========================================================================

SCHEMA_FUNDAMENTALISTA = """
CREATE TABLE IF NOT EXISTS fundamentalista (
    ticker TEXT NOT NULL,
    data DATE NOT NULL,
    
    -- Valuation
    p_l REAL,           -- Preço/Lucro
    p_vp REAL,          -- Preço/Valor Patrimonial
    p_ebit REAL,        -- Preço/EBIT
    psr REAL,           -- Price/Sales Ratio
    p_ativo REAL,       -- Preço/Ativo Total
    p_cap_giro REAL,    -- Preço/Capital de Giro
    p_ativ_circ_liq REAL, -- Preço/Ativo Circulante Líquido
    
    -- Rentabilidade
    dy REAL,            -- Dividend Yield
    roe REAL,           -- Return on Equity
    roic REAL,          -- Return on Invested Capital
    roa REAL,           -- Return on Assets
    liq_corrente REAL,  -- Liquidez Corrente
    
    -- Endividamento
    div_brut_patrim REAL,  -- Dívida Bruta/Patrimônio
    divida_ebit REAL,      -- Dívida/EBIT
    
    -- Crescimento
    cagr_receita_5a REAL,  -- CAGR Receita 5 anos
    cagr_lucro_5a REAL,    -- CAGR Lucro 5 anos
    
    -- Eficiência
    margem_bruta REAL,
    margem_ebit REAL,
    margem_liquida REAL,
    
    -- Liquidez de mercado
    vol_med_2m REAL,       -- Volume médio 2 meses (R$)
    
    PRIMARY KEY (ticker, data)
)
"""

SCHEMA_PRECOS = """
CREATE TABLE IF NOT EXISTS precos (
    ticker TEXT NOT NULL,
    data DATE NOT NULL,
    
    open REAL NOT NULL,
    high REAL NOT NULL,
    low REAL NOT NULL,
    close REAL NOT NULL,
    volume INTEGER NOT NULL,
    
    dy_12m REAL DEFAULT 0.0,  -- Dividend Yield últimos 12 meses
    
    PRIMARY KEY (ticker, data)
)
"""


# ===========================================================================
# Classe principal
# ===========================================================================

class Database:
    """Gerenciador de conexões e operações do banco de dados"""
    
    def __init__(self):
        # Criar pasta data/ se não existir
        Path("data").mkdir(exist_ok=True)
        
        self.db_fundamentalista = CFG["database"]["fundamentalista_db"]
        self.db_precos = CFG["database"]["precos_db"]
        
        # Inicializar schemas
        self._init_schema()
    
    def _init_schema(self):
        """Cria tabelas se não existirem"""
        # Fundamentalista
        conn = sqlite3.connect(self.db_fundamentalista)
        conn.execute(SCHEMA_FUNDAMENTALISTA)
        conn.commit()
        conn.close()
        
        # Preços
        conn = sqlite3.connect(self.db_precos)
        conn.execute(SCHEMA_PRECOS)
        conn.commit()
        conn.close()
    
    # -----------------------------------------------------------------------
    # FUNDAMENTALISTA
    # -----------------------------------------------------------------------
    
    def inserir_fundamentalista(self, dados: List[Dict]):
        """
        Insere/atualiza dados fundamentalistas.
        
        Args:
            dados: Lista de dicts com keys: ticker, data, p_l, dy, roe, etc.
        """
        conn = sqlite3.connect(self.db_fundamentalista)
        
        for row in dados:
            # Prepara placeholders
            colunas = list(row.keys())
            placeholders = ", ".join(["?" for _ in colunas])
            valores = [row[c] for c in colunas]
            
            # INSERT OR REPLACE
            sql = f"""
                INSERT OR REPLACE INTO fundamentalista 
                ({", ".join(colunas)})
                VALUES ({placeholders})
            """
            
            conn.execute(sql, valores)
        
        conn.commit()
        conn.close()
    
    def buscar_fundamentalista(self, ticker: str, data_inicio: str, data_fim: str) -> pd.DataFrame:
        """
        Busca dados fundamentalistas de um ticker em período.
        
        Returns:
            DataFrame com colunas: data, p_l, dy, roe, etc.
        """
        conn = sqlite3.connect(self.db_fundamentalista)
        
        df = pd.read_sql_query(
            """
            SELECT * FROM fundamentalista
            WHERE ticker = ?
              AND data >= ?
              AND data <= ?
            ORDER BY data
            """,
            conn,
            params=(ticker, data_inicio, data_fim)
        )
        
        conn.close()
        return df
    
    def buscar_todos_fundamentalista(self, data: str) -> pd.DataFrame:
        """
        Busca dados fundamentalistas de TODOS os tickers em uma data específica.
        Usado no screening para identificar oportunidades.
        
        Returns:
            DataFrame com colunas: ticker, p_l, dy, roe, etc.
        """
        conn = sqlite3.connect(self.db_fundamentalista)
        
        df = pd.read_sql_query(
            """
            SELECT * FROM fundamentalista
            WHERE data = ?
            """,
            conn,
            params=(data,)
        )
        
        conn.close()
        return df
    
    # -----------------------------------------------------------------------
    # PREÇOS
    # -----------------------------------------------------------------------
    
    def inserir_precos(self, dados: List[Dict]):
        """
        Insere/atualiza preços históricos.
        
        Args:
            dados: Lista de dicts com keys: ticker, data, open, high, low, close, volume, dy_12m
        """
        conn = sqlite3.connect(self.db_precos)
        
        for row in dados:
            # Extrai dy_12m se existir, senão usa 0.0
            dy_12m = row.get("dy_12m", 0.0)
            
            conn.execute(
                """
                INSERT OR REPLACE INTO precos 
                (ticker, data, open, high, low, close, volume, dy_12m)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (row["ticker"], row["data"], row["open"], row["high"], 
                 row["low"], row["close"], row["volume"], dy_12m)
            )
        
        conn.commit()
        conn.close()
    
    def buscar_precos(self, ticker: str, data_inicio: str, data_fim: str) -> pd.DataFrame:
        """
        Busca preços de um ticker em período.
        
        Returns:
            DataFrame com colunas: data, open, high, low, close, volume
        """
        conn = sqlite3.connect(self.db_precos)
        
        df = pd.read_sql_query(
            """
            SELECT * FROM precos
            WHERE ticker = ?
              AND data >= ?
              AND data <= ?
            ORDER BY data
            """,
            conn,
            params=(ticker, data_inicio, data_fim),
            parse_dates=["data"]
        )
        
        conn.close()
        return df
    
    def buscar_preco_em_data(self, ticker: str, data: str) -> Optional[float]:
        """
        Busca close de um ticker em data específica.
        
        Returns:
            Preço de fechamento ou None se não encontrado
        """
        conn = sqlite3.connect(self.db_precos)
        
        cursor = conn.execute(
            "SELECT close FROM precos WHERE ticker = ? AND data = ?",
            (ticker, data)
        )
        
        row = cursor.fetchone()
        conn.close()
        
        return row[0] if row else None
    
    # -----------------------------------------------------------------------
    # UTILIDADES
    # -----------------------------------------------------------------------
    
    def listar_tickers_com_dados(self) -> List[str]:
        """Retorna lista de tickers que têm dados fundamentalistas"""
        conn = sqlite3.connect(self.db_fundamentalista)
        
        cursor = conn.execute(
            "SELECT DISTINCT ticker FROM fundamentalista ORDER BY ticker"
        )
        
        tickers = [row[0] for row in cursor.fetchall()]
        conn.close()
        
        return tickers
    
    def contar_registros_fundamentalista(self, ticker: str) -> int:
        """Conta quantos snapshots fundamentalistas existem para um ticker"""
        conn = sqlite3.connect(self.db_fundamentalista)
        
        cursor = conn.execute(
            "SELECT COUNT(*) FROM fundamentalista WHERE ticker = ?",
            (ticker,)
        )
        
        count = cursor.fetchone()[0]
        conn.close()
        
        return count
    
    def contar_registros_precos(self, ticker: str) -> int:
        """Conta quantos dias de preços existem para um ticker"""
        conn = sqlite3.connect(self.db_precos)
        
        cursor = conn.execute(
            "SELECT COUNT(*) FROM precos WHERE ticker = ?",
            (ticker,)
        )
        
        count = cursor.fetchone()[0]
        conn.close()
        
        return count


# ===========================================================================
# Funções de conveniência
# ===========================================================================

def get_db() -> Database:
    """Retorna instância única do banco (singleton)"""
    if not hasattr(get_db, "_instance"):
        get_db._instance = Database()
    return get_db._instance


# ===========================================================================
# Testes
# ===========================================================================

if __name__ == "__main__":
    db = get_db()
    
    print("\n" + "="*70)
    print("TESTE DO DATABASE")
    print("="*70 + "\n")
    
    # Teste: Inserir dados de exemplo
    print("1. Inserindo dados de teste...")
    
    dados_fund = [
        {
            "ticker": "PETR4.SA",
            "data": "2024-01-15",
            "p_l": 4.5,
            "dy": 0.08,
            "roe": 0.20,
            "p_vp": 0.8,
            "vol_med_2m": 50000000,
        },
        {
            "ticker": "VALE3.SA",
            "data": "2024-01-15",
            "p_l": 3.2,
            "dy": 0.10,
            "roe": 0.18,
            "p_vp": 0.6,
            "vol_med_2m": 80000000,
        }
    ]
    
    db.inserir_fundamentalista(dados_fund)
    print("   [OK] Fundamentalista inserido")
    
    dados_precos = [
        {
            "ticker": "PETR4.SA",
            "data": "2024-01-15",
            "open": 35.0,
            "high": 36.0,
            "low": 34.5,
            "close": 35.8,
            "volume": 10000000
        }
    ]
    
    db.inserir_precos(dados_precos)
    print("   [OK] Precos inseridos\n")
    
    # Teste: Buscar
    print("2. Buscando dados...")
    
    df_fund = db.buscar_todos_fundamentalista("2024-01-15")
    print(f"   Fundamentalista em 2024-01-15: {len(df_fund)} registros")
    print(df_fund[["ticker", "p_l", "dy", "roe"]].to_string(index=False))
    
    preco = db.buscar_preco_em_data("PETR4.SA", "2024-01-15")
    print(f"\n   Preço PETR4 em 2024-01-15: R$ {preco:.2f}")
    
    print("\n" + "="*70)
    print("[OK] Testes concluidos com sucesso!")
    print("="*70 + "\n")