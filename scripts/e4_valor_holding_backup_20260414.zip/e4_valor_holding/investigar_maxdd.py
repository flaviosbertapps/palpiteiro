"""
Investigação: MaxDD -100%
==========================
Por que drawdown deu -100%?
"""

import sqlite3
import pandas as pd
import json

with open("e4_config.json") as f:
    CFG = json.load(f)

# Simula alguns trades para ver se há problema
print("="*70)
print("INVESTIGAÇÃO: MaxDD -100%")
print("="*70)

# Busca preços de PETR4 e CSNA3
conn_precos = sqlite3.connect("data/precos.db")

for ticker in ["PETR4.SA", "CSNA3.SA"]:
    print(f"\n{ticker}:")
    
    df = pd.read_sql(f"""
        SELECT data, close
        FROM precos
        WHERE ticker = '{ticker}'
        ORDER BY data
    """, conn_precos)
    
    if df.empty:
        print("  Sem dados")
        continue
    
    print(f"  Período: {df['data'].min()} a {df['data'].max()}")
    print(f"  Dias: {len(df)}")
    print(f"  Preço min: R$ {df['close'].min():.2f}")
    print(f"  Preço max: R$ {df['close'].max():.2f}")
    
    # Verifica se algum preço chegou perto de zero
    precos_baixos = df[df['close'] < 1.0]
    
    if len(precos_baixos) > 0:
        print(f"\n  ⚠ ATENÇÃO: {len(precos_baixos)} dias com preço < R$ 1.00!")
        print(precos_baixos[['data', 'close']].to_string(index=False))
    
    # Verifica maior queda sequencial
    df['ret'] = df['close'].pct_change()
    maior_queda = df['ret'].min()
    
    print(f"\n  Maior queda diária: {maior_queda*100:.1f}%")
    
    if maior_queda < -0.5:
        print(f"  ⚠ Queda > 50% em 1 dia! (possível split/desdobramento)")

conn_precos.close()

print("\n" + "="*70)
print("HIPÓTESES:")
print("="*70)
print("1. Bug no cálculo de MaxDD no código")
print("2. Trade ficou preso até papel ir a zero (improvável)")
print("3. Dados de preço com erro (split não ajustado)")
print("\nPRÓXIMO: Ver código do cálculo de MaxDD em e4_screening.py")